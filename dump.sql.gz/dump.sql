-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	8.0.36-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `id` int NOT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `countryCode` varchar(255) NOT NULL,
  `administrativeArea` varchar(255) DEFAULT NULL,
  `locality` varchar(255) DEFAULT NULL,
  `dependentLocality` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `sortingCode` varchar(255) DEFAULT NULL,
  `addressLine1` varchar(255) DEFAULT NULL,
  `addressLine2` varchar(255) DEFAULT NULL,
  `addressLine3` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `organizationTaxId` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_hnpcnmaefgueimhrrxvyrarbpgcnlmcqvtny` (`primaryOwnerId`),
  CONSTRAINT `fk_ditovfajwdizbnfzwssmvfacviabnhkyugun` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_hnpcnmaefgueimhrrxvyrarbpgcnlmcqvtny` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
INSERT INTO `addresses` VALUES (14,NULL,NULL,'US',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2024-07-02 18:26:45','2024-07-02 18:26:45');
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `pluginId` int DEFAULT NULL,
  `heading` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `unread` tinyint(1) NOT NULL DEFAULT '1',
  `dateRead` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ldxvwkpzznwdojdkostjqhgcdizrikgvjwxv` (`userId`,`unread`,`dateRead`,`dateCreated`),
  KEY `idx_pmfxbfiuwgstpharknmioavmckxupfuebmyo` (`dateRead`),
  KEY `fk_fuhuxqzgissfsakpymhydipxlfhceseakhay` (`pluginId`),
  CONSTRAINT `fk_dkhmwilyrmzwmgpuvjrkjntczagroktufrbo` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_fuhuxqzgissfsakpymhydipxlfhceseakhay` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexdata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sessionId` int NOT NULL,
  `volumeId` int NOT NULL,
  `uri` text,
  `size` bigint unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `isDir` tinyint(1) DEFAULT '0',
  `recordId` int DEFAULT NULL,
  `isSkipped` tinyint(1) DEFAULT '0',
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_iwkfwzevbsjktoieotmytqimdfiuqdemuspn` (`sessionId`,`volumeId`),
  KEY `idx_jncijmlqrklorlqsxeclwcamlrigvhilwgrx` (`volumeId`),
  CONSTRAINT `fk_rqcyoemnzlqkglxomdwxwzptabhfzmacalty` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ypvmlznnginxwwushzkzprxwjdxlaievqujz` FOREIGN KEY (`sessionId`) REFERENCES `assetindexingsessions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexdata`
--

LOCK TABLES `assetindexdata` WRITE;
/*!40000 ALTER TABLE `assetindexdata` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexingsessions`
--

DROP TABLE IF EXISTS `assetindexingsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexingsessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `indexedVolumes` text,
  `totalEntries` int DEFAULT NULL,
  `processedEntries` int NOT NULL DEFAULT '0',
  `cacheRemoteImages` tinyint(1) DEFAULT NULL,
  `listEmptyFolders` tinyint(1) DEFAULT '0',
  `isCli` tinyint(1) DEFAULT '0',
  `actionRequired` tinyint(1) DEFAULT '0',
  `processIfRootEmpty` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexingsessions`
--

LOCK TABLES `assetindexingsessions` WRITE;
/*!40000 ALTER TABLE `assetindexingsessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexingsessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets` (
  `id` int NOT NULL,
  `volumeId` int DEFAULT NULL,
  `folderId` int NOT NULL,
  `uploaderId` int DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `alt` text,
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `size` bigint unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_rttlopkxllygfgarteminufofihhnfutbtum` (`filename`,`folderId`),
  KEY `idx_dslfqysbpvsfrkaxzpgobdvloywzbtynexkj` (`folderId`),
  KEY `idx_qiarflkezpwjksopuyhukxipdkbrpqkchyde` (`volumeId`),
  KEY `fk_mtvtlfwscjijtfwnpiaywjrqyliffaoonpar` (`uploaderId`),
  CONSTRAINT `fk_itugvgfiwvpwrppxfianudmolykcsmxdqthh` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mtvtlfwscjijtfwnpiaywjrqyliffaoonpar` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_pbilfwuzolcgnbdkyeaimvotqrdlmnwgrgje` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_uakzihimnuurkpnjvkfnynxafgzebqjwiutm` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets_sites`
--

DROP TABLE IF EXISTS `assets_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets_sites` (
  `assetId` int NOT NULL,
  `siteId` int NOT NULL,
  `alt` text,
  PRIMARY KEY (`assetId`,`siteId`),
  KEY `fk_uymwtusqindmnyjbqbrhqlnivixrvooexxbf` (`siteId`),
  CONSTRAINT `fk_uymwtusqindmnyjbqbrhqlnivixrvooexxbf` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_xsqtscyuqlcxdysrmnipwezebulkecnzyxky` FOREIGN KEY (`assetId`) REFERENCES `assets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets_sites`
--

LOCK TABLES `assets_sites` WRITE;
/*!40000 ALTER TABLE `assets_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `assets_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authenticator`
--

DROP TABLE IF EXISTS `authenticator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authenticator` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `auth2faSecret` varchar(255) DEFAULT NULL,
  `oldTimestamp` int unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_nrvswlrxidpkvonynklnkusoojlnfpwnjjua` (`userId`),
  CONSTRAINT `fk_nrvswlrxidpkvonynklnkusoojlnfpwnjjua` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authenticator`
--

LOCK TABLES `authenticator` WRITE;
/*!40000 ALTER TABLE `authenticator` DISABLE KEYS */;
/*!40000 ALTER TABLE `authenticator` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_rylzhcjshmdmhzmetbxvwtyodqwujjcucvca` (`groupId`),
  KEY `fk_bakgunxnlgdojbktidbpljlqphdarlfqcswl` (`parentId`),
  CONSTRAINT `fk_bakgunxnlgdojbktidbpljlqphdarlfqcswl` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_lvozwpdebvhchcnihiqjusbfytwgpjqpasih` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_phefwtpywjbtgqlputbczxfdftvnrizdbfbe` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qmauypuwuimrtqyxxkwyfigrdvywjqnanuxw` (`name`),
  KEY `idx_guksaurotlnroemynlhxjhhzpotjmkjunjbq` (`handle`),
  KEY `idx_chprakudxyxirwwyikrrlfurthiheozwlxnz` (`structureId`),
  KEY `idx_oavhmwjtqsdqmmqtjzdpqfesonossuycrrus` (`fieldLayoutId`),
  KEY `idx_iszkaqeohzuugkobbiauwumueagdfdbuassy` (`dateDeleted`),
  CONSTRAINT `fk_ewcxrdfrfgsjdydqxvddudrtgdfslpdznguy` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_iaabmjwuiwgkikhspcrwhzltshqsvcdusdyw` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tcqskjrqexdbklznxjpllihpmkjctycrmmug` (`groupId`,`siteId`),
  KEY `idx_jxtaoajomebhmldrdxqhpxprnbpfnwvmzhhz` (`siteId`),
  CONSTRAINT `fk_cujqqdfowyokqbfdwzfjdixoxlumlmdbbduo` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_vranfyjqxekmmspywhgecpuohrhokzqgmnxd` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedattributes`
--

DROP TABLE IF EXISTS `changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedattributes` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_ezspbgzhtysnyshxyoqcqznmbppfxgnczdkz` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_pdzoxevvavdfdzlweelmmpbbeloplfccktuu` (`siteId`),
  KEY `fk_gncxudwlpngjsskmxettgilnhfbgbdodlqgc` (`userId`),
  CONSTRAINT `fk_gncxudwlpngjsskmxettgilnhfbgbdodlqgc` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_pdzoxevvavdfdzlweelmmpbbeloplfccktuu` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_xamncvgerlndrzgsdiolnrcutkrseibcimlg` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedattributes`
--

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;
INSERT INTO `changedattributes` VALUES (16,1,'slug','2024-07-02 18:29:54',0,1),(16,1,'title','2024-07-02 18:29:54',0,1),(16,1,'uri','2024-07-02 18:29:54',0,1),(16,1,'variants','2024-07-02 18:30:05',0,1);
/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedfields`
--

DROP TABLE IF EXISTS `changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedfields` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `fieldId` int NOT NULL,
  `layoutElementUid` char(36) NOT NULL DEFAULT '0',
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`,`layoutElementUid`),
  KEY `idx_igjznnixhzyksarqasuxibouaoskjfivymio` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_znerzotfuqjlkgohzogweeybpkrefupwlnjz` (`siteId`),
  KEY `fk_suovtbimvbfncfkavadtvkzdeoqshagusefd` (`fieldId`),
  KEY `fk_gdxymcismwpbucrbbjgjtevhaandlraqhbzf` (`userId`),
  CONSTRAINT `fk_gdxymcismwpbucrbbjgjtevhaandlraqhbzf` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_sdaveqracuuejkiwdivqmlszbeokrybyvvtr` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_suovtbimvbfncfkavadtvkzdeoqshagusefd` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_znerzotfuqjlkgohzogweeybpkrefupwlnjz` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedfields`
--

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;
INSERT INTO `changedfields` VALUES (16,1,1,'6e43c6c9-f5a4-42a8-a1de-161847fc7b69','2024-07-02 18:30:05',0,1);
/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_catalogpricing`
--

DROP TABLE IF EXISTS `commerce_catalogpricing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_catalogpricing` (
  `id` int NOT NULL AUTO_INCREMENT,
  `price` decimal(14,4) DEFAULT NULL,
  `purchasableId` int NOT NULL,
  `storeId` int DEFAULT NULL,
  `catalogPricingRuleId` int DEFAULT NULL,
  `userId` int DEFAULT NULL,
  `dateFrom` datetime DEFAULT NULL,
  `dateTo` datetime DEFAULT NULL,
  `isPromotionalPrice` tinyint(1) DEFAULT '0',
  `hasUpdatePending` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_wjilcpdyivdwjtxdaubwxokuxjxdemswmabs` (`catalogPricingRuleId`),
  KEY `idx_snmpdmcyixrfjwwogfwojxdeuqdewzmcuyuc` (`purchasableId`),
  KEY `idx_liuepsbleblejmhvxdrdnosoutyfptequpcf` (`storeId`),
  KEY `idx_vtvooycxuoqpkicufsrkpfwsqlvzzlqhvcuw` (`userId`),
  KEY `idx_burxnwdigdpwmjfnmljatbpvwtaubzzttisc` (`isPromotionalPrice`),
  KEY `idx_efdcguwrxrpkkmkunmfxddkwvyyynklrxgbe` (`purchasableId`,`storeId`),
  CONSTRAINT `fk_jvglypjnmomusssoeulgmtaapxbkauzsczii` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ljschwevwjepdwbkvkziqivfpfqovxjcdsok` FOREIGN KEY (`catalogPricingRuleId`) REFERENCES `commerce_catalogpricingrules` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rongyaifgsvsmvcwkesevobpizgortjxpran` FOREIGN KEY (`storeId`) REFERENCES `commerce_stores` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_viyyozvrqwdqnpexqlkcnikmbrdehmybnukm` FOREIGN KEY (`purchasableId`) REFERENCES `commerce_purchasables` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_catalogpricing`
--

LOCK TABLES `commerce_catalogpricing` WRITE;
/*!40000 ALTER TABLE `commerce_catalogpricing` DISABLE KEYS */;
INSERT INTO `commerce_catalogpricing` VALUES (2,NULL,13,1,NULL,NULL,NULL,NULL,0,0,'2024-07-02 18:04:19','2024-07-02 18:04:19','809f5bfe-389d-11ef-a00f-0242c0a8a503'),(10,0.0000,17,1,NULL,NULL,NULL,NULL,0,0,'2024-07-02 18:30:06','2024-07-02 18:30:06','1af21057-38a1-11ef-a00f-0242c0a8a503');
/*!40000 ALTER TABLE `commerce_catalogpricing` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_catalogpricingrules`
--

DROP TABLE IF EXISTS `commerce_catalogpricingrules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_catalogpricingrules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text,
  `storeId` int NOT NULL,
  `dateFrom` datetime DEFAULT NULL,
  `dateTo` datetime DEFAULT NULL,
  `apply` enum('toPercent','toFlat','byPercent','byFlat') NOT NULL,
  `applyAmount` decimal(14,4) NOT NULL,
  `applyPriceType` enum('price','promotionalPrice') NOT NULL,
  `purchasableCondition` text,
  `purchasableId` int DEFAULT NULL,
  `customerCondition` text,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `isPromotionalPrice` tinyint(1) NOT NULL DEFAULT '0',
  `metadata` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_gkwlbgsyngygssacgavfhlbobkhabpgzmkta` (`purchasableId`),
  KEY `idx_keuaompcwxnujhdwytdbbhpcfndevifgowps` (`storeId`),
  CONSTRAINT `fk_mnwxcuwtfuwdxszqwpondjrdvsfejvgxofik` FOREIGN KEY (`purchasableId`) REFERENCES `commerce_purchasables` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_zgghhflncwvxfntwcovophysvouvpyzkithb` FOREIGN KEY (`storeId`) REFERENCES `commerce_stores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_catalogpricingrules`
--

LOCK TABLES `commerce_catalogpricingrules` WRITE;
/*!40000 ALTER TABLE `commerce_catalogpricingrules` DISABLE KEYS */;
/*!40000 ALTER TABLE `commerce_catalogpricingrules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_catalogpricingrules_users`
--

DROP TABLE IF EXISTS `commerce_catalogpricingrules_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_catalogpricingrules_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `catalogPricingRuleId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_xnldtkzvnrgbowaeudryjswxezlefhxbmslj` (`catalogPricingRuleId`),
  KEY `idx_octwoooewqfeuamniqfokmmctxfnunvyjezk` (`userId`),
  CONSTRAINT `fk_afpylnupmuokghbnhdimuhxptyaxydlbpyii` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_gzhvtqjttsfteprmtxtzeujhllgynpezxkbb` FOREIGN KEY (`catalogPricingRuleId`) REFERENCES `commerce_catalogpricingrules` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_catalogpricingrules_users`
--

LOCK TABLES `commerce_catalogpricingrules_users` WRITE;
/*!40000 ALTER TABLE `commerce_catalogpricingrules_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `commerce_catalogpricingrules_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_coupons`
--

DROP TABLE IF EXISTS `commerce_coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_coupons` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(255) DEFAULT NULL,
  `discountId` int NOT NULL,
  `uses` int NOT NULL DEFAULT '0',
  `maxUses` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_thkdxgwpejdljlwwrzitnhqgekhdouluwayw` (`code`),
  KEY `idx_pkmejtfpuyzxerfawgicybxntrcraodtyryf` (`discountId`),
  CONSTRAINT `fk_safddpjhecpbbkjvjzsdbxpkxnbzraqdlogh` FOREIGN KEY (`discountId`) REFERENCES `commerce_discounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_coupons`
--

LOCK TABLES `commerce_coupons` WRITE;
/*!40000 ALTER TABLE `commerce_coupons` DISABLE KEYS */;
/*!40000 ALTER TABLE `commerce_coupons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_customer_discountuses`
--

DROP TABLE IF EXISTS `commerce_customer_discountuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_customer_discountuses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `discountId` int NOT NULL,
  `customerId` int NOT NULL,
  `uses` int unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_vvcabzuwoxxkzunrohunfheryupbolhdmodk` (`customerId`,`discountId`),
  KEY `idx_vwlhjcvbjextiuskhvmvnrfdarnzhlqjufuc` (`discountId`),
  CONSTRAINT `fk_hoekvozsnhvddfowckvosemhjegvowdpnbis` FOREIGN KEY (`customerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_ufxothfytipgcbcqdtteqxpgackdqbrggron` FOREIGN KEY (`discountId`) REFERENCES `commerce_discounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_customer_discountuses`
--

LOCK TABLES `commerce_customer_discountuses` WRITE;
/*!40000 ALTER TABLE `commerce_customer_discountuses` DISABLE KEYS */;
/*!40000 ALTER TABLE `commerce_customer_discountuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_customers`
--

DROP TABLE IF EXISTS `commerce_customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_customers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `customerId` int NOT NULL,
  `primaryBillingAddressId` int DEFAULT NULL,
  `primaryShippingAddressId` int DEFAULT NULL,
  `primaryPaymentSourceId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_vybhzwxqssitwpsngixdsdprkxmahexhfdqj` (`customerId`),
  KEY `idx_omqkpzzvmttngjfmjxhthxhtggqirrrzgkkx` (`primaryBillingAddressId`),
  KEY `idx_shiehbzinsxjajgihhiuqqczulagecpahmgl` (`primaryPaymentSourceId`),
  KEY `idx_fjgysogdnxflgnkptclkiblrjjljrrcrvsuj` (`primaryShippingAddressId`),
  CONSTRAINT `fk_iwwscsfalnggvaabxadhmjkqwveldfdqwbbb` FOREIGN KEY (`primaryBillingAddressId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_sdngapwsldkgmiygocwunbmqttgedwsccmoo` FOREIGN KEY (`customerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_ssthtqxjohcvmajswtvkjxdgedttghieyrhg` FOREIGN KEY (`primaryPaymentSourceId`) REFERENCES `commerce_paymentsources` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_wektfeobcssybhotqygnyseixbjdzvmbkcrx` FOREIGN KEY (`primaryShippingAddressId`) REFERENCES `elements` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_customers`
--

LOCK TABLES `commerce_customers` WRITE;
/*!40000 ALTER TABLE `commerce_customers` DISABLE KEYS */;
/*!40000 ALTER TABLE `commerce_customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_discount_categories`
--

DROP TABLE IF EXISTS `commerce_discount_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_discount_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `discountId` int NOT NULL,
  `categoryId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_cseqzibmsnaolbffgcdmiytgsejzjookjzqy` (`discountId`,`categoryId`),
  KEY `idx_qwucqgexmuuxtzqlocpqcfzfdkdmvnvhnquz` (`categoryId`),
  CONSTRAINT `fk_cxpvvdrkbtzkhcgrbvizdephpuvhbeftgnio` FOREIGN KEY (`discountId`) REFERENCES `commerce_discounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_hyxriawqxfqvxnzbozjvebcxtpxyxljpmone` FOREIGN KEY (`categoryId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_discount_categories`
--

LOCK TABLES `commerce_discount_categories` WRITE;
/*!40000 ALTER TABLE `commerce_discount_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `commerce_discount_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_discount_purchasables`
--

DROP TABLE IF EXISTS `commerce_discount_purchasables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_discount_purchasables` (
  `id` int NOT NULL AUTO_INCREMENT,
  `discountId` int NOT NULL,
  `purchasableId` int NOT NULL,
  `purchasableType` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_xpnxmkpeyvgqacrdxfaawvvqepnkbrinvalx` (`discountId`,`purchasableId`),
  KEY `idx_yajchxzokfqotddbojdgwudufofmciihbzan` (`purchasableId`),
  CONSTRAINT `fk_idcbqxiasrpaknwmmiowitbsajpqztzzqppj` FOREIGN KEY (`purchasableId`) REFERENCES `commerce_purchasables` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_nslyqgqmhcjlchwittmlkcojwgfnjumzquim` FOREIGN KEY (`discountId`) REFERENCES `commerce_discounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_discount_purchasables`
--

LOCK TABLES `commerce_discount_purchasables` WRITE;
/*!40000 ALTER TABLE `commerce_discount_purchasables` DISABLE KEYS */;
/*!40000 ALTER TABLE `commerce_discount_purchasables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_discounts`
--

DROP TABLE IF EXISTS `commerce_discounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_discounts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `storeId` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text,
  `couponFormat` varchar(20) NOT NULL DEFAULT '######',
  `orderCondition` text,
  `customerCondition` text,
  `shippingAddressCondition` text,
  `billingAddressCondition` text,
  `perUserLimit` int unsigned NOT NULL DEFAULT '0',
  `perEmailLimit` int unsigned NOT NULL DEFAULT '0',
  `totalDiscountUses` int unsigned NOT NULL DEFAULT '0',
  `totalDiscountUseLimit` int unsigned NOT NULL DEFAULT '0',
  `dateFrom` datetime DEFAULT NULL,
  `dateTo` datetime DEFAULT NULL,
  `purchaseQty` int NOT NULL DEFAULT '0',
  `purchaseTotal` decimal(14,4) NOT NULL DEFAULT '0.0000',
  `maxPurchaseQty` int NOT NULL DEFAULT '0',
  `baseDiscount` decimal(14,4) NOT NULL DEFAULT '0.0000',
  `perItemDiscount` decimal(14,4) NOT NULL DEFAULT '0.0000',
  `percentDiscount` decimal(14,4) NOT NULL DEFAULT '0.0000',
  `percentageOffSubject` enum('original','discounted') NOT NULL,
  `excludeOnPromotion` tinyint(1) NOT NULL DEFAULT '0',
  `hasFreeShippingForMatchingItems` tinyint(1) NOT NULL DEFAULT '0',
  `hasFreeShippingForOrder` tinyint(1) NOT NULL DEFAULT '0',
  `allPurchasables` tinyint(1) NOT NULL DEFAULT '0',
  `purchasableIds` text,
  `allCategories` tinyint(1) NOT NULL DEFAULT '0',
  `categoryIds` text,
  `appliedTo` enum('matchingLineItems','allLineItems') NOT NULL DEFAULT 'matchingLineItems',
  `categoryRelationshipType` enum('element','sourceElement','targetElement') NOT NULL DEFAULT 'element',
  `orderConditionFormula` text,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `stopProcessing` tinyint(1) NOT NULL DEFAULT '0',
  `ignorePromotions` tinyint(1) NOT NULL DEFAULT '0',
  `sortOrder` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qvlmkqkroecdaapapdeicezjaezffkjkamff` (`dateFrom`),
  KEY `idx_wqzwppebbgksforulojnrinvontffzhdcvij` (`dateTo`),
  KEY `fk_zzekemkjglknovflusxwmnmecocrdjbouwwm` (`storeId`),
  CONSTRAINT `fk_zzekemkjglknovflusxwmnmecocrdjbouwwm` FOREIGN KEY (`storeId`) REFERENCES `commerce_stores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_discounts`
--

LOCK TABLES `commerce_discounts` WRITE;
/*!40000 ALTER TABLE `commerce_discounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `commerce_discounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_donations`
--

DROP TABLE IF EXISTS `commerce_donations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_donations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sku` varchar(255) NOT NULL,
  `availableForPurchase` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_dbeizzeycujbmrryxkbtncybfiqyssljvwyn` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_donations`
--

LOCK TABLES `commerce_donations` WRITE;
/*!40000 ALTER TABLE `commerce_donations` DISABLE KEYS */;
/*!40000 ALTER TABLE `commerce_donations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_email_discountuses`
--

DROP TABLE IF EXISTS `commerce_email_discountuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_email_discountuses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `discountId` int NOT NULL,
  `email` varchar(255) NOT NULL,
  `uses` int unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_onxzzqdtwsvaaxwquqtmvlbjsbtxaiippjel` (`email`,`discountId`),
  KEY `idx_fsodojsjgxlcyowkcpkwatteyauattkvxxcb` (`discountId`),
  CONSTRAINT `fk_ihagpnqchdvgabtlldlusembvuxpjkwirxhh` FOREIGN KEY (`discountId`) REFERENCES `commerce_discounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_email_discountuses`
--

LOCK TABLES `commerce_email_discountuses` WRITE;
/*!40000 ALTER TABLE `commerce_email_discountuses` DISABLE KEYS */;
/*!40000 ALTER TABLE `commerce_email_discountuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_emails`
--

DROP TABLE IF EXISTS `commerce_emails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_emails` (
  `id` int NOT NULL AUTO_INCREMENT,
  `storeId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `senderAddress` varchar(255) DEFAULT NULL,
  `senderName` varchar(255) DEFAULT NULL,
  `subject` varchar(255) NOT NULL,
  `recipientType` enum('customer','custom') DEFAULT 'custom',
  `to` varchar(255) DEFAULT NULL,
  `bcc` varchar(255) DEFAULT NULL,
  `cc` varchar(255) DEFAULT NULL,
  `replyTo` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `templatePath` varchar(255) NOT NULL,
  `plainTextTemplatePath` varchar(255) DEFAULT NULL,
  `pdfId` int DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_pwbwlmvpumrsfrcbvfwfrouggbcymyiexkzl` (`storeId`),
  KEY `fk_dtygagezxscgdgcyawfbiycysduolbnwmfzn` (`pdfId`),
  CONSTRAINT `fk_dtygagezxscgdgcyawfbiycysduolbnwmfzn` FOREIGN KEY (`pdfId`) REFERENCES `commerce_pdfs` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_nxeuvaklqjxagybroxrvsnsaqiytifcxqjby` FOREIGN KEY (`storeId`) REFERENCES `commerce_stores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_emails`
--

LOCK TABLES `commerce_emails` WRITE;
/*!40000 ALTER TABLE `commerce_emails` DISABLE KEYS */;
/*!40000 ALTER TABLE `commerce_emails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_gateways`
--

DROP TABLE IF EXISTS `commerce_gateways`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_gateways` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `settings` text,
  `paymentType` enum('authorize','purchase') NOT NULL DEFAULT 'purchase',
  `isFrontendEnabled` varchar(500) NOT NULL DEFAULT '1',
  `isArchived` tinyint(1) NOT NULL DEFAULT '0',
  `dateArchived` datetime DEFAULT NULL,
  `sortOrder` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_jagydivzswtggxzdzqgbuxlvacetxmpvrblf` (`handle`),
  KEY `idx_gowlrcxblnhhpyyrhpfgfjlqzuursvybhted` (`isArchived`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_gateways`
--

LOCK TABLES `commerce_gateways` WRITE;
/*!40000 ALTER TABLE `commerce_gateways` DISABLE KEYS */;
INSERT INTO `commerce_gateways` VALUES (1,'craft\\commerce\\gateways\\Dummy','Dummy','dummy',NULL,'purchase','1',0,NULL,99,'2024-07-02 17:30:54','2024-07-02 17:30:54','22ed0f81-7934-43be-9e7e-8cfe3587c410');
/*!40000 ALTER TABLE `commerce_gateways` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_inventoryitems`
--

DROP TABLE IF EXISTS `commerce_inventoryitems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_inventoryitems` (
  `id` int NOT NULL AUTO_INCREMENT,
  `purchasableId` int NOT NULL,
  `countryCodeOfOrigin` varchar(255) DEFAULT NULL,
  `administrativeAreaCodeOfOrigin` varchar(255) DEFAULT NULL,
  `harmonizedSystemCode` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tginpopedecwbxtrblexanfucynlcaknwbwz` (`purchasableId`),
  CONSTRAINT `fk_npychppzpggalzblhmngdpppwlnvqiczkefo` FOREIGN KEY (`purchasableId`) REFERENCES `commerce_purchasables` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_inventoryitems`
--

LOCK TABLES `commerce_inventoryitems` WRITE;
/*!40000 ALTER TABLE `commerce_inventoryitems` DISABLE KEYS */;
INSERT INTO `commerce_inventoryitems` VALUES (1,13,'','','','2024-07-02 18:04:13','2024-07-02 18:04:13','6a917003-3ee2-4586-bb03-883bd4c9406e'),(2,17,'','','','2024-07-02 18:29:55','2024-07-02 18:29:55','df8b1e62-8be7-49bc-9441-925a29e3241b');
/*!40000 ALTER TABLE `commerce_inventoryitems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_inventorylocations`
--

DROP TABLE IF EXISTS `commerce_inventorylocations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_inventorylocations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `addressId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_rytxlnuweuzfohtwxvehlhzpmsxubtaahokh` (`addressId`),
  CONSTRAINT `fk_rytxlnuweuzfohtwxvehlhzpmsxubtaahokh` FOREIGN KEY (`addressId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_inventorylocations`
--

LOCK TABLES `commerce_inventorylocations` WRITE;
/*!40000 ALTER TABLE `commerce_inventorylocations` DISABLE KEYS */;
INSERT INTO `commerce_inventorylocations` VALUES (1,'default','Default',NULL,'2024-07-02 17:30:54','2024-07-02 17:30:54',NULL,'44e2cc42-ff60-458c-aa4c-5b42f28e22f7');
/*!40000 ALTER TABLE `commerce_inventorylocations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_inventorylocations_stores`
--

DROP TABLE IF EXISTS `commerce_inventorylocations_stores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_inventorylocations_stores` (
  `id` int NOT NULL AUTO_INCREMENT,
  `inventoryLocationId` int NOT NULL,
  `storeId` int NOT NULL,
  `sortOrder` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_opjgibmlitulolpudpfdjcapqveookiuxnjf` (`inventoryLocationId`),
  KEY `fk_jgcroevjjlfcnakpgddycdbsafegdmvkzyrg` (`storeId`),
  CONSTRAINT `fk_jgcroevjjlfcnakpgddycdbsafegdmvkzyrg` FOREIGN KEY (`storeId`) REFERENCES `commerce_stores` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_opjgibmlitulolpudpfdjcapqveookiuxnjf` FOREIGN KEY (`inventoryLocationId`) REFERENCES `commerce_inventorylocations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_inventorylocations_stores`
--

LOCK TABLES `commerce_inventorylocations_stores` WRITE;
/*!40000 ALTER TABLE `commerce_inventorylocations_stores` DISABLE KEYS */;
INSERT INTO `commerce_inventorylocations_stores` VALUES (1,1,1,1,'2024-07-02 17:30:54','2024-07-02 17:30:54','289c9e82-cca8-4a75-8361-f0c169d51a14');
/*!40000 ALTER TABLE `commerce_inventorylocations_stores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_inventorytransactions`
--

DROP TABLE IF EXISTS `commerce_inventorytransactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_inventorytransactions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `inventoryLocationId` int NOT NULL,
  `inventoryItemId` int NOT NULL,
  `movementHash` varchar(255) NOT NULL,
  `quantity` int NOT NULL,
  `type` enum('incoming','available','committed','reserved','damaged','safety','fulfilled','qualityControl') NOT NULL,
  `note` varchar(255) DEFAULT NULL,
  `transferId` int DEFAULT NULL,
  `lineItemId` int DEFAULT NULL,
  `userId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_wklzhefpyxhtqzanzftaxylubvdhqstdopmk` (`inventoryItemId`),
  KEY `idx_dxhdugyshgbmxlalpotqnbeemofbixomtlww` (`lineItemId`),
  KEY `idx_lupatmprixxxwmappxwyyimsktwzjcriayji` (`transferId`),
  KEY `idx_xilteuruvmcwzuyuqmplmbmzhbkwxuucorpd` (`userId`),
  KEY `fk_jnsapipggfyhjlbusypzbjnxnzysplcqncbm` (`inventoryLocationId`),
  CONSTRAINT `fk_agwvrlupooiawftnfhtbvcgoaskbzppswzkw` FOREIGN KEY (`transferId`) REFERENCES `commerce_transfers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_jnsapipggfyhjlbusypzbjnxnzysplcqncbm` FOREIGN KEY (`inventoryLocationId`) REFERENCES `commerce_inventorylocations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mgtcxkgbmhdjjrvfvsmtghrtxjpyhemhazrl` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_pstuwqfnjiinpzyuwqrkhpbzwhohytnlreqb` FOREIGN KEY (`lineItemId`) REFERENCES `commerce_lineitems` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wztqacepwbcvnpdefodstdsdbdwrhmbujftm` FOREIGN KEY (`inventoryItemId`) REFERENCES `commerce_inventoryitems` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zhwugmtuebtogedwcbysnwstbpsvihqsasnz` FOREIGN KEY (`transferId`) REFERENCES `commerce_transfers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_inventorytransactions`
--

LOCK TABLES `commerce_inventorytransactions` WRITE;
/*!40000 ALTER TABLE `commerce_inventorytransactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `commerce_inventorytransactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_lineitems`
--

DROP TABLE IF EXISTS `commerce_lineitems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_lineitems` (
  `id` int NOT NULL AUTO_INCREMENT,
  `orderId` int NOT NULL,
  `purchasableId` int DEFAULT NULL,
  `taxCategoryId` int NOT NULL,
  `shippingCategoryId` int NOT NULL,
  `description` text,
  `options` text,
  `optionsSignature` varchar(255) NOT NULL,
  `price` decimal(14,4) unsigned NOT NULL,
  `promotionalPrice` decimal(14,4) unsigned DEFAULT NULL,
  `promotionalAmount` decimal(14,4) NOT NULL DEFAULT '0.0000',
  `salePrice` decimal(14,4) NOT NULL DEFAULT '0.0000',
  `sku` varchar(255) DEFAULT NULL,
  `weight` decimal(14,4) unsigned NOT NULL DEFAULT '0.0000',
  `height` decimal(14,4) unsigned NOT NULL DEFAULT '0.0000',
  `length` decimal(14,4) unsigned NOT NULL DEFAULT '0.0000',
  `width` decimal(14,4) unsigned NOT NULL DEFAULT '0.0000',
  `subtotal` decimal(14,4) unsigned NOT NULL DEFAULT '0.0000',
  `total` decimal(14,4) NOT NULL DEFAULT '0.0000',
  `qty` int unsigned NOT NULL,
  `note` text,
  `privateNote` text,
  `snapshot` longtext,
  `lineItemStatusId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lbhsqziiemqdurufbfcxkvdanwhdifexwvha` (`orderId`,`purchasableId`,`optionsSignature`),
  KEY `idx_beexmctvrjphdgqyeryrjbbcgleecdmnuawk` (`purchasableId`),
  KEY `idx_wagdmcvqdxstnntejgaljdjuqonltekcdzyx` (`shippingCategoryId`),
  KEY `idx_hqkmkgtxqgnjcplukijoahyijmqaiiuesnes` (`taxCategoryId`),
  CONSTRAINT `fk_kcjgnysfubusdjarlacnuplvyedhaxgdhmck` FOREIGN KEY (`purchasableId`) REFERENCES `elements` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_lbqrhwednsqfivedlpgskvlyfektoypvpqpi` FOREIGN KEY (`orderId`) REFERENCES `commerce_orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mnuovsodswoymhmtjqxdqfbrhibvuwnhufcz` FOREIGN KEY (`shippingCategoryId`) REFERENCES `commerce_shippingcategories` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_tnljptmltcgkvwtpnkrplmujnxkewbllhwfa` FOREIGN KEY (`taxCategoryId`) REFERENCES `commerce_taxcategories` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_lineitems`
--

LOCK TABLES `commerce_lineitems` WRITE;
/*!40000 ALTER TABLE `commerce_lineitems` DISABLE KEYS */;
/*!40000 ALTER TABLE `commerce_lineitems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_lineitemstatuses`
--

DROP TABLE IF EXISTS `commerce_lineitemstatuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_lineitemstatuses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `storeId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `color` enum('green','orange','red','blue','yellow','pink','purple','turquoise','light','grey','black') NOT NULL DEFAULT 'green',
  `isArchived` tinyint(1) NOT NULL DEFAULT '0',
  `dateArchived` datetime DEFAULT NULL,
  `sortOrder` int DEFAULT NULL,
  `default` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_miziecxmfwdkifictvvveyiuztbkkipfusgm` (`storeId`),
  CONSTRAINT `fk_mqcocscvsgtmtvybgvtekjlraztirxemvpfj` FOREIGN KEY (`storeId`) REFERENCES `commerce_stores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_lineitemstatuses`
--

LOCK TABLES `commerce_lineitemstatuses` WRITE;
/*!40000 ALTER TABLE `commerce_lineitemstatuses` DISABLE KEYS */;
/*!40000 ALTER TABLE `commerce_lineitemstatuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_orderadjustments`
--

DROP TABLE IF EXISTS `commerce_orderadjustments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_orderadjustments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `orderId` int NOT NULL,
  `lineItemId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `amount` decimal(14,4) NOT NULL,
  `included` tinyint(1) NOT NULL DEFAULT '0',
  `isEstimated` tinyint(1) NOT NULL DEFAULT '0',
  `sourceSnapshot` longtext,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qkvlhlfwbsclryativjjyvghffrmynqdypur` (`orderId`),
  CONSTRAINT `fk_hgvwkgaljackthcaafjiroysbvzcojqsobpv` FOREIGN KEY (`orderId`) REFERENCES `commerce_orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_orderadjustments`
--

LOCK TABLES `commerce_orderadjustments` WRITE;
/*!40000 ALTER TABLE `commerce_orderadjustments` DISABLE KEYS */;
/*!40000 ALTER TABLE `commerce_orderadjustments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_orderhistories`
--

DROP TABLE IF EXISTS `commerce_orderhistories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_orderhistories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `orderId` int NOT NULL,
  `userId` int DEFAULT NULL,
  `userName` varchar(255) DEFAULT NULL,
  `prevStatusId` int DEFAULT NULL,
  `newStatusId` int DEFAULT NULL,
  `message` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bjffvdluayazytawaedikurcnsstpfmyibtc` (`newStatusId`),
  KEY `idx_ubxzwzscffzlwgjjrragyogzhjshfhxxxkqo` (`orderId`),
  KEY `idx_rucjwlmfeqtgzhtfnpbjmibhbzfdwhptqkbw` (`prevStatusId`),
  KEY `idx_jwfoitqqfrdukbkioiuizjridejqwnoajqcx` (`userId`),
  CONSTRAINT `fk_cknaympkdjlkdjifydomhmrkswuaygsdccei` FOREIGN KEY (`orderId`) REFERENCES `commerce_orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_dzvruvrlmebwogganvopwegfdlgucyzlwzpj` FOREIGN KEY (`prevStatusId`) REFERENCES `commerce_orderstatuses` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_jhqvtqvsxrpowrywkalvilkgzsictwoefvml` FOREIGN KEY (`userId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_rcealqwpzbhdhlzgxlfxdyxshchmdvzahcqj` FOREIGN KEY (`newStatusId`) REFERENCES `commerce_orderstatuses` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_orderhistories`
--

LOCK TABLES `commerce_orderhistories` WRITE;
/*!40000 ALTER TABLE `commerce_orderhistories` DISABLE KEYS */;
/*!40000 ALTER TABLE `commerce_orderhistories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_ordernotices`
--

DROP TABLE IF EXISTS `commerce_ordernotices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_ordernotices` (
  `id` int NOT NULL AUTO_INCREMENT,
  `orderId` int NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  `attribute` varchar(255) DEFAULT NULL,
  `message` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_vbykgougqqtpwsybvbxpznsijkspqqcmbuqm` (`orderId`),
  CONSTRAINT `fk_ahnswvgzubzpdiukyrbyqqmyimumzvdzvecm` FOREIGN KEY (`orderId`) REFERENCES `commerce_orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_ordernotices`
--

LOCK TABLES `commerce_ordernotices` WRITE;
/*!40000 ALTER TABLE `commerce_ordernotices` DISABLE KEYS */;
/*!40000 ALTER TABLE `commerce_ordernotices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_orders`
--

DROP TABLE IF EXISTS `commerce_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_orders` (
  `id` int NOT NULL,
  `storeId` int NOT NULL,
  `billingAddressId` int DEFAULT NULL,
  `shippingAddressId` int DEFAULT NULL,
  `estimatedBillingAddressId` int DEFAULT NULL,
  `estimatedShippingAddressId` int DEFAULT NULL,
  `sourceShippingAddressId` int DEFAULT NULL,
  `sourceBillingAddressId` int DEFAULT NULL,
  `gatewayId` int DEFAULT NULL,
  `paymentSourceId` int DEFAULT NULL,
  `customerId` int DEFAULT NULL,
  `orderStatusId` int DEFAULT NULL,
  `number` varchar(32) DEFAULT NULL,
  `reference` varchar(255) DEFAULT NULL,
  `couponCode` varchar(255) DEFAULT NULL,
  `itemTotal` decimal(14,4) DEFAULT '0.0000',
  `itemSubtotal` decimal(14,4) DEFAULT '0.0000',
  `totalQty` int unsigned DEFAULT NULL,
  `totalWeight` decimal(14,4) unsigned DEFAULT '0.0000',
  `total` decimal(14,4) DEFAULT '0.0000',
  `totalPrice` decimal(14,4) DEFAULT '0.0000',
  `totalPaid` decimal(14,4) DEFAULT '0.0000',
  `totalDiscount` decimal(14,4) DEFAULT '0.0000',
  `totalTax` decimal(14,4) DEFAULT '0.0000',
  `totalTaxIncluded` decimal(14,4) DEFAULT '0.0000',
  `totalShippingCost` decimal(14,4) DEFAULT '0.0000',
  `paidStatus` enum('paid','partial','unpaid','overPaid') DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `orderCompletedEmail` varchar(255) DEFAULT NULL,
  `isCompleted` tinyint(1) NOT NULL DEFAULT '0',
  `dateOrdered` datetime DEFAULT NULL,
  `datePaid` datetime DEFAULT NULL,
  `dateAuthorized` datetime DEFAULT NULL,
  `currency` varchar(255) DEFAULT NULL,
  `paymentCurrency` varchar(255) DEFAULT NULL,
  `lastIp` varchar(255) DEFAULT NULL,
  `orderLanguage` varchar(12) NOT NULL,
  `origin` enum('web','cp','remote') NOT NULL DEFAULT 'web',
  `message` text,
  `registerUserOnOrderComplete` tinyint(1) NOT NULL DEFAULT '0',
  `saveBillingAddressOnOrderComplete` tinyint(1) NOT NULL DEFAULT '0',
  `saveShippingAddressOnOrderComplete` tinyint(1) NOT NULL DEFAULT '0',
  `recalculationMode` enum('all','none','adjustmentsOnly') NOT NULL DEFAULT 'all',
  `returnUrl` text,
  `cancelUrl` text,
  `shippingMethodHandle` varchar(255) NOT NULL DEFAULT '',
  `shippingMethodName` varchar(255) NOT NULL DEFAULT '',
  `orderSiteId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_mfilhdblahpqysbhmkfzfytglnwrxqeyixzb` (`number`),
  KEY `idx_fwxvwfjklwmeusxmdqwbocpibsaikwhpkubo` (`billingAddressId`),
  KEY `idx_nwbbfnbtkwqfueoshioqfqmzhbljvwefvnvk` (`customerId`),
  KEY `idx_kwvsjiogbbbmzhmjduqezqnbtpstjfyussql` (`email`),
  KEY `idx_knujbqbbhpakytnclnzulpiborewmgnorwdi` (`estimatedBillingAddressId`),
  KEY `idx_xqzrcczeagboutbqkloefzxwfictowwfxjsk` (`estimatedShippingAddressId`),
  KEY `idx_qdetgirozjpwuskudozztuufvvkcagpofjez` (`gatewayId`),
  KEY `idx_gpisrfdshccusuuntjjsirwegdsdomplkyax` (`orderStatusId`),
  KEY `idx_mpwxlzovtzqgymhpwkijyumjtawdzdsbkegl` (`reference`),
  KEY `idx_zetmofajiihuwordgvnctvrlapfrrncazgum` (`shippingAddressId`),
  KEY `idx_fuvirqfstfoqxkmsgfrqpavdkysvtzoscpvb` (`sourceBillingAddressId`),
  KEY `idx_yzsmjsgluazljltjqecgmubtcdpujtcxqirf` (`sourceShippingAddressId`),
  KEY `idx_kdtddvpxysrjgnlvwpjegvnyuansnahbvdgb` (`storeId`),
  KEY `fk_upbjpjsmczjvedpujxqcxnvvdqelxvotpkgj` (`paymentSourceId`),
  CONSTRAINT `fk_bjycdwfijtobmxmlzmirlescyjvyytctusqs` FOREIGN KEY (`gatewayId`) REFERENCES `commerce_gateways` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_cuzxkdjuifcwvvmvfdbholfckaifktexwfed` FOREIGN KEY (`estimatedBillingAddressId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_dprlworubrthpoomvcllotknswkkwgydpljr` FOREIGN KEY (`storeId`) REFERENCES `commerce_stores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_jjapnlhugtorxnmsdnbveoqowjyvaicrhbvi` FOREIGN KEY (`orderStatusId`) REFERENCES `commerce_orderstatuses` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_odckmcbtvyuotbzefcvohgqevibbgpwsflox` FOREIGN KEY (`estimatedShippingAddressId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_qsxuzsqcohprhtjveombipjsdpcgesqqdbza` FOREIGN KEY (`shippingAddressId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_tenrflrduyqnamvcyhiwxzxewvqmjjfzxtvv` FOREIGN KEY (`billingAddressId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_upbjpjsmczjvedpujxqcxnvvdqelxvotpkgj` FOREIGN KEY (`paymentSourceId`) REFERENCES `commerce_paymentsources` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_wuimtcjbijhdeptkqbeydmsxbrzmlcrfjpps` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yyvnicktyakiopwgwhqyijkllevbrneemeoa` FOREIGN KEY (`customerId`) REFERENCES `elements` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_orders`
--

LOCK TABLES `commerce_orders` WRITE;
/*!40000 ALTER TABLE `commerce_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `commerce_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_orderstatus_emails`
--

DROP TABLE IF EXISTS `commerce_orderstatus_emails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_orderstatus_emails` (
  `id` int NOT NULL AUTO_INCREMENT,
  `orderStatusId` int NOT NULL,
  `emailId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_dzakeyupmydmilumjocyxrxzbyctpafwwetv` (`emailId`),
  KEY `idx_uwahhjjrwxeerogyeeiygyxylskxjxhmfbsg` (`orderStatusId`),
  CONSTRAINT `fk_mncknumfjbayoupcqoskfpzchwvfieygyalp` FOREIGN KEY (`orderStatusId`) REFERENCES `commerce_orderstatuses` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_tunongsudofavwkybuayagophwremgjtjkxw` FOREIGN KEY (`emailId`) REFERENCES `commerce_emails` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_orderstatus_emails`
--

LOCK TABLES `commerce_orderstatus_emails` WRITE;
/*!40000 ALTER TABLE `commerce_orderstatus_emails` DISABLE KEYS */;
/*!40000 ALTER TABLE `commerce_orderstatus_emails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_orderstatuses`
--

DROP TABLE IF EXISTS `commerce_orderstatuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_orderstatuses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `storeId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `color` enum('green','orange','red','blue','yellow','pink','purple','turquoise','light','grey','black') NOT NULL DEFAULT 'green',
  `description` varchar(255) DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `sortOrder` int DEFAULT NULL,
  `default` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bbutakptesjyhflnoqvejjeuosmdqgpdtzvn` (`storeId`),
  CONSTRAINT `fk_rnqonfygsldxlolulptmakmrmxgyfvdzlfzv` FOREIGN KEY (`storeId`) REFERENCES `commerce_stores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_orderstatuses`
--

LOCK TABLES `commerce_orderstatuses` WRITE;
/*!40000 ALTER TABLE `commerce_orderstatuses` DISABLE KEYS */;
INSERT INTO `commerce_orderstatuses` VALUES (1,1,'New','new','green',NULL,NULL,99,1,'2024-07-02 17:30:54','2024-07-02 17:30:54','e2e770f1-9ee6-4664-a29c-482aa27e753a');
/*!40000 ALTER TABLE `commerce_orderstatuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_paymentcurrencies`
--

DROP TABLE IF EXISTS `commerce_paymentcurrencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_paymentcurrencies` (
  `id` int NOT NULL AUTO_INCREMENT,
  `storeId` int NOT NULL,
  `iso` varchar(3) NOT NULL,
  `primary` tinyint(1) NOT NULL DEFAULT '0',
  `rate` decimal(14,4) NOT NULL DEFAULT '0.0000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_kjvzsjcnlrsmwtlwspmwaytjnredtulpjpwd` (`iso`),
  KEY `fk_anstreqrrhftbjwohyokrqzxqwhqyhowxuzt` (`storeId`),
  CONSTRAINT `fk_anstreqrrhftbjwohyokrqzxqwhqyhowxuzt` FOREIGN KEY (`storeId`) REFERENCES `commerce_stores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_paymentcurrencies`
--

LOCK TABLES `commerce_paymentcurrencies` WRITE;
/*!40000 ALTER TABLE `commerce_paymentcurrencies` DISABLE KEYS */;
INSERT INTO `commerce_paymentcurrencies` VALUES (1,1,'USD',0,1.0000,'2024-07-02 17:30:54','2024-07-02 17:30:54','78bebe4e-97af-4454-a96e-025d99ccb5ae'),(2,1,'EUR',0,1.0000,'2024-07-02 18:26:53','2024-07-02 18:26:53','f6356eae-4528-44cc-83d9-8648fab625c2');
/*!40000 ALTER TABLE `commerce_paymentcurrencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_paymentsources`
--

DROP TABLE IF EXISTS `commerce_paymentsources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_paymentsources` (
  `id` int NOT NULL AUTO_INCREMENT,
  `customerId` int NOT NULL,
  `gatewayId` int NOT NULL,
  `token` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `response` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_nrflnwjhhfzjqrkqhmogvprkaphnycraixsz` (`customerId`),
  KEY `fk_xvbtcmokgzlvdsqesbdkikovfzxcobrgrkze` (`gatewayId`),
  CONSTRAINT `fk_nrflnwjhhfzjqrkqhmogvprkaphnycraixsz` FOREIGN KEY (`customerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xvbtcmokgzlvdsqesbdkikovfzxcobrgrkze` FOREIGN KEY (`gatewayId`) REFERENCES `commerce_gateways` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_paymentsources`
--

LOCK TABLES `commerce_paymentsources` WRITE;
/*!40000 ALTER TABLE `commerce_paymentsources` DISABLE KEYS */;
/*!40000 ALTER TABLE `commerce_paymentsources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_pdfs`
--

DROP TABLE IF EXISTS `commerce_pdfs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_pdfs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `storeId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `templatePath` varchar(255) NOT NULL,
  `fileNameFormat` varchar(255) DEFAULT NULL,
  `paperOrientation` varchar(255) DEFAULT 'portrait',
  `paperSize` varchar(255) DEFAULT 'letter',
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `isDefault` tinyint(1) NOT NULL DEFAULT '0',
  `sortOrder` int DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_vpaalsvdqbunkytmsiuyqbnkjmnkkkbsxjfq` (`handle`),
  KEY `idx_kjpbrxaacsgjvsqdrcathkhvkgqfkwknwpck` (`storeId`),
  CONSTRAINT `fk_tnrefnkyxjvrrlyyryptrnvsmkuvexxbqprz` FOREIGN KEY (`storeId`) REFERENCES `commerce_stores` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_pdfs`
--

LOCK TABLES `commerce_pdfs` WRITE;
/*!40000 ALTER TABLE `commerce_pdfs` DISABLE KEYS */;
/*!40000 ALTER TABLE `commerce_pdfs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_plans`
--

DROP TABLE IF EXISTS `commerce_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_plans` (
  `id` int NOT NULL AUTO_INCREMENT,
  `gatewayId` int DEFAULT NULL,
  `planInformationId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `reference` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `planData` text,
  `isArchived` tinyint(1) NOT NULL DEFAULT '0',
  `dateArchived` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `sortOrder` int DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_colfzdxfmlvinunmtatylzmaucxehrmlwjpd` (`handle`),
  KEY `idx_kpdiuhljomckrfyaucgfbckemljyucgnnktg` (`gatewayId`),
  KEY `idx_uepjldqgbjfytwrtqpbakvbdyxksirzziaye` (`reference`),
  KEY `fk_adytxctatzlncexhniqyfoiqwonhuhzykpbi` (`planInformationId`),
  CONSTRAINT `fk_adytxctatzlncexhniqyfoiqwonhuhzykpbi` FOREIGN KEY (`planInformationId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_xwuhlbeorjhwlvkhflntanvpjigluhysfmlp` FOREIGN KEY (`gatewayId`) REFERENCES `commerce_gateways` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_plans`
--

LOCK TABLES `commerce_plans` WRITE;
/*!40000 ALTER TABLE `commerce_plans` DISABLE KEYS */;
/*!40000 ALTER TABLE `commerce_plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_products`
--

DROP TABLE IF EXISTS `commerce_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_products` (
  `id` int NOT NULL,
  `typeId` int DEFAULT NULL,
  `defaultVariantId` int DEFAULT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `defaultSku` varchar(255) DEFAULT NULL,
  `defaultPrice` decimal(14,4) DEFAULT NULL,
  `defaultHeight` decimal(14,4) DEFAULT NULL,
  `defaultLength` decimal(14,4) DEFAULT NULL,
  `defaultWidth` decimal(14,4) DEFAULT NULL,
  `defaultWeight` decimal(14,4) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_pbjdkllrsmvsukrvoolbjyecfulnnrghjkwe` (`expiryDate`),
  KEY `idx_pwndzswvjgldgbbygdnbzcwjcikfpggdhhds` (`postDate`),
  KEY `idx_gncrsdaftzuvzowqgxzsqaayrkftbfdcqbqo` (`typeId`),
  CONSTRAINT `fk_ryctjgrirfpcuysuzezphdcypqycebaqrcuh` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ubsahmazwtlajkbldnsqfvmkifausiozvjda` FOREIGN KEY (`typeId`) REFERENCES `commerce_producttypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_products`
--

LOCK TABLES `commerce_products` WRITE;
/*!40000 ALTER TABLE `commerce_products` DISABLE KEYS */;
INSERT INTO `commerce_products` VALUES (2,1,NULL,'2024-07-02 17:49:00',NULL,'1719942569',10.0000,0.0000,0.0000,0.0000,0.0000,'2024-07-02 17:49:29','2024-07-02 17:49:29','bba74c0d-5146-4081-b24d-efa7261d7b4e'),(3,1,NULL,'2024-07-02 17:49:00',NULL,'1719942593',10.0000,0.0000,0.0000,0.0000,0.0000,'2024-07-02 17:49:53','2024-07-02 17:49:53','03cbe85e-6ad2-491b-88b9-e0b2ffd79723'),(4,1,NULL,'2024-07-02 17:53:00',NULL,'1719942803',10.0000,0.0000,0.0000,0.0000,0.0000,'2024-07-02 17:53:23','2024-07-02 17:53:23','167c3442-18a7-4409-aa4b-ba9bf5956cae'),(5,1,NULL,'2024-07-02 17:54:00',NULL,'1719942899',10.0000,0.0000,0.0000,0.0000,0.0000,'2024-07-02 17:54:59','2024-07-02 17:54:59','ef519676-1d53-4f21-8c34-5dd3b484727c'),(6,1,NULL,'2024-07-02 18:00:00',NULL,'1719943225',10.0000,0.0000,0.0000,0.0000,0.0000,'2024-07-02 18:00:25','2024-07-02 18:00:25','9341de4e-4efb-4f5a-b218-561733f869f8'),(7,1,NULL,'2024-07-02 18:01:00',NULL,'1719943274',10.0000,0.0000,0.0000,0.0000,0.0000,'2024-07-02 18:01:14','2024-07-02 18:01:15','7704e908-4b2a-4a16-a6e2-c2172a3cedd1'),(8,1,NULL,'2024-07-02 18:02:00',NULL,'',0.0000,0.0000,0.0000,0.0000,0.0000,'2024-07-02 18:02:46','2024-07-02 18:02:46','cf444c24-c3ce-41cc-bc3c-d5c4c6f897b7'),(9,1,NULL,'2024-07-02 18:03:00',NULL,'',0.0000,0.0000,0.0000,0.0000,0.0000,'2024-07-02 18:03:00','2024-07-02 18:03:00','359b7350-ede7-4d07-8aac-d2a98162da92'),(10,1,NULL,'2024-07-02 18:03:00',NULL,'',0.0000,0.0000,0.0000,0.0000,0.0000,'2024-07-02 18:03:41','2024-07-02 18:03:41','225c5104-a66c-4d7e-b1b6-5bdf4d0650dc'),(11,1,NULL,'2024-07-02 18:03:00',NULL,'',0.0000,0.0000,0.0000,0.0000,0.0000,'2024-07-02 18:03:55','2024-07-02 18:03:55','24bcff3c-2023-47f4-990d-faeb1eec7318'),(12,1,13,'2024-07-02 18:04:00',NULL,'1719943453',10.0000,0.0000,0.0000,0.0000,0.0000,'2024-07-02 18:04:13','2024-07-02 18:04:14','e68cd342-7267-40b5-8e2f-85a938b2b203'),(16,1,17,'2024-07-02 18:29:52',NULL,'123',0.0000,0.0000,0.0000,0.0000,0.0000,'2024-07-02 18:29:52','2024-07-02 18:30:05','af84f92b-8db6-488d-923a-da9e4bcf3c31');
/*!40000 ALTER TABLE `commerce_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_producttypes`
--

DROP TABLE IF EXISTS `commerce_producttypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_producttypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `variantFieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `maxVariants` int DEFAULT NULL,
  `hasDimensions` tinyint(1) NOT NULL DEFAULT '0',
  `hasVariantTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `variantTitleFormat` varchar(255) NOT NULL,
  `hasProductTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `productTitleFormat` varchar(255) DEFAULT NULL,
  `skuFormat` varchar(255) DEFAULT NULL,
  `descriptionFormat` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_esivntxnmduhmsosxwabeqmdjmxjvbzatqgh` (`handle`),
  KEY `idx_qixlcszhqbnexszhslsndjstkdjdsuljzqgt` (`fieldLayoutId`),
  KEY `idx_juowzbgzipvdyorqpoifmgbvcymvezsrsikb` (`variantFieldLayoutId`),
  CONSTRAINT `fk_bhivgpamfsvcxguuwndsolaekmoyhvsyvkds` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_hcniofsucjgpoawdofebylanniboqsgtlodu` FOREIGN KEY (`variantFieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_producttypes`
--

LOCK TABLES `commerce_producttypes` WRITE;
/*!40000 ALTER TABLE `commerce_producttypes` DISABLE KEYS */;
INSERT INTO `commerce_producttypes` VALUES (1,1,2,'General','general',0,NULL,0,1,'{product.title}',1,'','','{product.title} - {title}','2024-07-02 17:37:32','2024-07-02 17:37:32','660b2918-0d3b-4556-ae6f-0e4f8adc5e83');
/*!40000 ALTER TABLE `commerce_producttypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_producttypes_shippingcategories`
--

DROP TABLE IF EXISTS `commerce_producttypes_shippingcategories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_producttypes_shippingcategories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `productTypeId` int NOT NULL,
  `shippingCategoryId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ninyabnnowqtrvvrytrancyrlrdtirptcpfk` (`productTypeId`,`shippingCategoryId`),
  KEY `idx_prlludyifmqiaixaxvtrztjcbaftjpislvqk` (`shippingCategoryId`),
  CONSTRAINT `fk_efrtvnfcqwulqmexbxymeiekcbemfstutqtt` FOREIGN KEY (`productTypeId`) REFERENCES `commerce_producttypes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_jfwlauqlfykimfnrdqslcqkzvlvervlticsf` FOREIGN KEY (`shippingCategoryId`) REFERENCES `commerce_shippingcategories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_producttypes_shippingcategories`
--

LOCK TABLES `commerce_producttypes_shippingcategories` WRITE;
/*!40000 ALTER TABLE `commerce_producttypes_shippingcategories` DISABLE KEYS */;
/*!40000 ALTER TABLE `commerce_producttypes_shippingcategories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_producttypes_sites`
--

DROP TABLE IF EXISTS `commerce_producttypes_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_producttypes_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `productTypeId` int NOT NULL,
  `siteId` int NOT NULL,
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_zenurskmccvrggnlhxqjdxdgaxwvavkyswlt` (`productTypeId`,`siteId`),
  KEY `idx_turpgasendezleivfxzzenmjqwsilhigudtl` (`siteId`),
  CONSTRAINT `fk_bldzawfzqqsthzbtkiavrkyckllgbnbuehbv` FOREIGN KEY (`productTypeId`) REFERENCES `commerce_producttypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_djtxyxtknmmvhhpyufizjkshbrwilvqubvmy` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_producttypes_sites`
--

LOCK TABLES `commerce_producttypes_sites` WRITE;
/*!40000 ALTER TABLE `commerce_producttypes_sites` DISABLE KEYS */;
INSERT INTO `commerce_producttypes_sites` VALUES (1,1,1,'general/{slug}','',1,'2024-07-02 17:37:32','2024-07-02 17:37:32','1f354452-6fd7-46e2-8f66-a2c49bff40c7');
/*!40000 ALTER TABLE `commerce_producttypes_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_producttypes_taxcategories`
--

DROP TABLE IF EXISTS `commerce_producttypes_taxcategories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_producttypes_taxcategories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `productTypeId` int NOT NULL,
  `taxCategoryId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_rkzecfopsdrvwcuzeittajfdxhpvnovmdbod` (`productTypeId`,`taxCategoryId`),
  KEY `idx_deonacxzfzqsftbmszkbqxyrkvoaigujfczx` (`taxCategoryId`),
  CONSTRAINT `fk_qkpbsmkvmrzxrubjxoadqkpeidzfsukukrzk` FOREIGN KEY (`taxCategoryId`) REFERENCES `commerce_taxcategories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zknjqwzsntqypsvxxwgxbkzqkxnizipmlkms` FOREIGN KEY (`productTypeId`) REFERENCES `commerce_producttypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_producttypes_taxcategories`
--

LOCK TABLES `commerce_producttypes_taxcategories` WRITE;
/*!40000 ALTER TABLE `commerce_producttypes_taxcategories` DISABLE KEYS */;
/*!40000 ALTER TABLE `commerce_producttypes_taxcategories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_purchasables`
--

DROP TABLE IF EXISTS `commerce_purchasables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_purchasables` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sku` varchar(255) NOT NULL,
  `description` text,
  `width` decimal(14,4) DEFAULT NULL,
  `height` decimal(14,4) DEFAULT NULL,
  `length` decimal(14,4) DEFAULT NULL,
  `weight` decimal(14,4) DEFAULT NULL,
  `taxCategoryId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_rvinlmzaorvxojzekdpsygaiajkycwdwfgst` (`sku`),
  KEY `fk_cgjmbprtrksvfcdlehhivreypjlwemljxbob` (`taxCategoryId`),
  CONSTRAINT `fk_cgjmbprtrksvfcdlehhivreypjlwemljxbob` FOREIGN KEY (`taxCategoryId`) REFERENCES `commerce_taxcategories` (`id`),
  CONSTRAINT `fk_shuhlxgvohxvtloapqlyfibfvuspsnlarkav` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_purchasables`
--

LOCK TABLES `commerce_purchasables` WRITE;
/*!40000 ALTER TABLE `commerce_purchasables` DISABLE KEYS */;
INSERT INTO `commerce_purchasables` VALUES (13,'1719943453','My test product - 1719943453 - My test variant - 1719943453',NULL,NULL,NULL,NULL,1,'2024-07-02 18:04:13','2024-07-02 18:04:13','21a159fd-1d7c-4ffd-89ae-5fced3f8ff73'),(17,'123','test - test123',NULL,NULL,NULL,NULL,1,'2024-07-02 18:29:55','2024-07-02 18:30:01','3dc57c98-6c87-4368-b27d-8f638d6543f1');
/*!40000 ALTER TABLE `commerce_purchasables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_purchasables_stores`
--

DROP TABLE IF EXISTS `commerce_purchasables_stores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_purchasables_stores` (
  `id` int NOT NULL AUTO_INCREMENT,
  `purchasableId` int NOT NULL,
  `storeId` int NOT NULL,
  `basePrice` decimal(14,4) DEFAULT NULL,
  `basePromotionalPrice` decimal(14,4) DEFAULT NULL,
  `promotable` tinyint(1) NOT NULL DEFAULT '0',
  `availableForPurchase` tinyint(1) NOT NULL DEFAULT '1',
  `freeShipping` tinyint(1) NOT NULL DEFAULT '1',
  `inventoryTracked` tinyint(1) NOT NULL DEFAULT '1',
  `stock` int DEFAULT NULL,
  `tracked` tinyint(1) NOT NULL DEFAULT '0',
  `minQty` int DEFAULT NULL,
  `maxQty` int DEFAULT NULL,
  `shippingCategoryId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_mfcractagufpcfsotceqfbeuystpxqkatfzv` (`purchasableId`),
  KEY `idx_vbmrrvmqnsavzjmkuyiacmbbrltpsgiyrgvt` (`storeId`),
  KEY `fk_zfgskksvajjfvfwyzbcotowokqukspcrirki` (`shippingCategoryId`),
  CONSTRAINT `fk_cjkvmkupzhcqkmjivydhicambnysosbvdpvm` FOREIGN KEY (`storeId`) REFERENCES `commerce_stores` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xuoxnbskrautuydhrjbipxzjltrapqahiatd` FOREIGN KEY (`purchasableId`) REFERENCES `commerce_purchasables` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zfgskksvajjfvfwyzbcotowokqukspcrirki` FOREIGN KEY (`shippingCategoryId`) REFERENCES `commerce_shippingcategories` (`id`),
  CONSTRAINT `fk_ztoinuagvexoeldbyjenfmyddrwkrkmqdlnc` FOREIGN KEY (`purchasableId`) REFERENCES `commerce_purchasables` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_purchasables_stores`
--

LOCK TABLES `commerce_purchasables_stores` WRITE;
/*!40000 ALTER TABLE `commerce_purchasables_stores` DISABLE KEYS */;
INSERT INTO `commerce_purchasables_stores` VALUES (1,13,1,NULL,NULL,0,1,0,0,0,0,NULL,NULL,1,'2024-07-02 18:04:13','2024-07-02 18:04:13','cb00d0bc-e30b-4a89-a9a1-1add53caa735'),(2,17,1,0.0000,NULL,0,1,0,0,0,0,NULL,NULL,1,'2024-07-02 18:29:55','2024-07-02 18:30:05','0da098ba-3e82-4103-8ab6-e8b3c05fe457');
/*!40000 ALTER TABLE `commerce_purchasables_stores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_sale_categories`
--

DROP TABLE IF EXISTS `commerce_sale_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_sale_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `saleId` int NOT NULL,
  `categoryId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_enllphycaodtkfrlvdttlkmocmyauvntcynx` (`saleId`,`categoryId`),
  KEY `idx_iuirycltmmlmkdioaatzjvwnztgomdephmwf` (`categoryId`),
  CONSTRAINT `fk_lpxscnxichilovxjsazqsudtcpcncutlnaas` FOREIGN KEY (`saleId`) REFERENCES `commerce_sales` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_ugkuffvpuvvsndkkchhoktddncacqkriqdrp` FOREIGN KEY (`categoryId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_sale_categories`
--

LOCK TABLES `commerce_sale_categories` WRITE;
/*!40000 ALTER TABLE `commerce_sale_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `commerce_sale_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_sale_purchasables`
--

DROP TABLE IF EXISTS `commerce_sale_purchasables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_sale_purchasables` (
  `id` int NOT NULL AUTO_INCREMENT,
  `saleId` int NOT NULL,
  `purchasableId` int NOT NULL,
  `purchasableType` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_xdykgqslppkviywnhdtcgbwwtckcndohrjmn` (`saleId`,`purchasableId`),
  KEY `idx_fumsyxrfhiajzenwvcofflqwxiqrmdjwozjz` (`purchasableId`),
  CONSTRAINT `fk_calaywrxcoxmsyszriuldkatlquwlgoabdan` FOREIGN KEY (`purchasableId`) REFERENCES `commerce_purchasables` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_ulcuimvmevpxjjajuecpnqltzsbqodemlwls` FOREIGN KEY (`saleId`) REFERENCES `commerce_sales` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_sale_purchasables`
--

LOCK TABLES `commerce_sale_purchasables` WRITE;
/*!40000 ALTER TABLE `commerce_sale_purchasables` DISABLE KEYS */;
/*!40000 ALTER TABLE `commerce_sale_purchasables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_sale_usergroups`
--

DROP TABLE IF EXISTS `commerce_sale_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_sale_usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `saleId` int NOT NULL,
  `userGroupId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lkedzybzehzcxemqkcsxnrzxsffkdyhxgqsz` (`saleId`,`userGroupId`),
  KEY `idx_ztdvtzhhqnpbgswpwrasmhinkfahrctryyyl` (`userGroupId`),
  CONSTRAINT `fk_grlzgjjpiqujpfuiggapfwqrtxtgmioijwvj` FOREIGN KEY (`saleId`) REFERENCES `commerce_sales` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_jvlqdeubmcjlosgqzisukrgqrdzyiicahdgo` FOREIGN KEY (`userGroupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_sale_usergroups`
--

LOCK TABLES `commerce_sale_usergroups` WRITE;
/*!40000 ALTER TABLE `commerce_sale_usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `commerce_sale_usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_sales`
--

DROP TABLE IF EXISTS `commerce_sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_sales` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text,
  `dateFrom` datetime DEFAULT NULL,
  `dateTo` datetime DEFAULT NULL,
  `apply` enum('toPercent','toFlat','byPercent','byFlat') NOT NULL,
  `applyAmount` decimal(14,4) NOT NULL,
  `allGroups` tinyint(1) NOT NULL DEFAULT '0',
  `allPurchasables` tinyint(1) NOT NULL DEFAULT '0',
  `allCategories` tinyint(1) NOT NULL DEFAULT '0',
  `categoryRelationshipType` enum('element','sourceElement','targetElement') NOT NULL DEFAULT 'element',
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `ignorePrevious` tinyint(1) NOT NULL DEFAULT '0',
  `stopProcessing` tinyint(1) NOT NULL DEFAULT '0',
  `sortOrder` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_sales`
--

LOCK TABLES `commerce_sales` WRITE;
/*!40000 ALTER TABLE `commerce_sales` DISABLE KEYS */;
/*!40000 ALTER TABLE `commerce_sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_shippingcategories`
--

DROP TABLE IF EXISTS `commerce_shippingcategories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_shippingcategories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `storeId` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `default` tinyint(1) NOT NULL DEFAULT '0',
  `dateDeleted` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_xcqviiavuurvslmlsbcjdbxwldnyujuabhlv` (`storeId`),
  CONSTRAINT `fk_vmlttrmcbypxseawnctzjqnullxpbvkzudxv` FOREIGN KEY (`storeId`) REFERENCES `commerce_stores` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_shippingcategories`
--

LOCK TABLES `commerce_shippingcategories` WRITE;
/*!40000 ALTER TABLE `commerce_shippingcategories` DISABLE KEYS */;
INSERT INTO `commerce_shippingcategories` VALUES (1,1,'General','general',NULL,1,NULL,'2024-07-02 17:30:54','2024-07-02 17:30:54','fe9a4c89-4783-45c3-aab8-f62e8dc34306');
/*!40000 ALTER TABLE `commerce_shippingcategories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_shippingmethods`
--

DROP TABLE IF EXISTS `commerce_shippingmethods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_shippingmethods` (
  `id` int NOT NULL AUTO_INCREMENT,
  `storeId` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `orderCondition` text,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_npfuuicytgbesyphucikizisyzahbynyetdm` (`name`),
  KEY `idx_iuzgieqrrcytuusjymufhdllvgdlylaesdhr` (`storeId`),
  CONSTRAINT `fk_zltugnhdqydhnimxxxwmoiewwsxdddiyebgg` FOREIGN KEY (`storeId`) REFERENCES `commerce_stores` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_shippingmethods`
--

LOCK TABLES `commerce_shippingmethods` WRITE;
/*!40000 ALTER TABLE `commerce_shippingmethods` DISABLE KEYS */;
/*!40000 ALTER TABLE `commerce_shippingmethods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_shippingrule_categories`
--

DROP TABLE IF EXISTS `commerce_shippingrule_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_shippingrule_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `shippingRuleId` int DEFAULT NULL,
  `shippingCategoryId` int DEFAULT NULL,
  `condition` enum('allow','disallow','require') NOT NULL,
  `perItemRate` decimal(14,4) DEFAULT NULL,
  `weightRate` decimal(14,4) DEFAULT NULL,
  `percentageRate` decimal(14,4) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_vszlfpzgajemeiikzlesgniafbfzdipryhte` (`shippingCategoryId`),
  KEY `idx_cgrcahcjlolaxslanbpjyyhxgbwdrhyegbfy` (`shippingRuleId`),
  CONSTRAINT `fk_gpdgbkerhkkinqwhlzbipcsrmlotlqypwyuu` FOREIGN KEY (`shippingCategoryId`) REFERENCES `commerce_shippingcategories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ntugrzymtzynsbrmnstppbbuatkdsnuyjgjg` FOREIGN KEY (`shippingRuleId`) REFERENCES `commerce_shippingrules` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_shippingrule_categories`
--

LOCK TABLES `commerce_shippingrule_categories` WRITE;
/*!40000 ALTER TABLE `commerce_shippingrule_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `commerce_shippingrule_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_shippingrules`
--

DROP TABLE IF EXISTS `commerce_shippingrules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_shippingrules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `methodId` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `priority` int NOT NULL DEFAULT '0',
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `orderConditionFormula` text,
  `orderCondition` text,
  `baseRate` decimal(14,4) NOT NULL DEFAULT '0.0000',
  `perItemRate` decimal(14,4) NOT NULL DEFAULT '0.0000',
  `weightRate` decimal(14,4) NOT NULL DEFAULT '0.0000',
  `percentageRate` decimal(14,4) NOT NULL DEFAULT '0.0000',
  `minRate` decimal(14,4) NOT NULL DEFAULT '0.0000',
  `maxRate` decimal(14,4) NOT NULL DEFAULT '0.0000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_tirqlhxwvbjdjzyqjfugpeqybhkgpgshqxki` (`methodId`),
  KEY `idx_turexbwumuiuxuboffsrfhaovwzpevxthlvk` (`name`),
  CONSTRAINT `fk_fknvgfyhjsbevqrxpjgpbtwxdktmiueujqwp` FOREIGN KEY (`methodId`) REFERENCES `commerce_shippingmethods` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_shippingrules`
--

LOCK TABLES `commerce_shippingrules` WRITE;
/*!40000 ALTER TABLE `commerce_shippingrules` DISABLE KEYS */;
/*!40000 ALTER TABLE `commerce_shippingrules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_shippingzones`
--

DROP TABLE IF EXISTS `commerce_shippingzones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_shippingzones` (
  `id` int NOT NULL AUTO_INCREMENT,
  `storeId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `condition` text,
  `default` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bitipwxcqhnnywrtysozyncngjytyeaxzqak` (`name`),
  KEY `idx_hfxgzgvrryjzisbreqbiwmqpbxmairareltj` (`storeId`),
  CONSTRAINT `fk_tngzsekjhedegquytbuzgekmespjhmrkjpcw` FOREIGN KEY (`storeId`) REFERENCES `commerce_stores` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_shippingzones`
--

LOCK TABLES `commerce_shippingzones` WRITE;
/*!40000 ALTER TABLE `commerce_shippingzones` DISABLE KEYS */;
/*!40000 ALTER TABLE `commerce_shippingzones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_site_stores`
--

DROP TABLE IF EXISTS `commerce_site_stores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_site_stores` (
  `siteId` int NOT NULL,
  `storeId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`siteId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_site_stores`
--

LOCK TABLES `commerce_site_stores` WRITE;
/*!40000 ALTER TABLE `commerce_site_stores` DISABLE KEYS */;
INSERT INTO `commerce_site_stores` VALUES (1,1,'2024-07-02 17:30:54','2024-07-02 17:30:54','6fc0244d-6ccb-4cb1-b1e5-c10752c00220');
/*!40000 ALTER TABLE `commerce_site_stores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_stores`
--

DROP TABLE IF EXISTS `commerce_stores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_stores` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `currency` varchar(255) NOT NULL DEFAULT 'USD',
  `autoSetCartShippingMethodOption` tinyint(1) NOT NULL DEFAULT '0',
  `autoSetNewCartAddresses` tinyint(1) NOT NULL DEFAULT '0',
  `autoSetPaymentSource` tinyint(1) NOT NULL DEFAULT '0',
  `allowEmptyCartOnCheckout` tinyint(1) NOT NULL DEFAULT '0',
  `allowCheckoutWithoutPayment` tinyint(1) NOT NULL DEFAULT '0',
  `allowPartialPaymentOnCheckout` tinyint(1) NOT NULL DEFAULT '0',
  `requireShippingAddressAtCheckout` tinyint(1) NOT NULL DEFAULT '0',
  `requireBillingAddressAtCheckout` tinyint(1) NOT NULL DEFAULT '0',
  `requireShippingMethodSelectionAtCheckout` tinyint(1) NOT NULL DEFAULT '0',
  `useBillingAddressForTax` tinyint(1) NOT NULL DEFAULT '0',
  `validateOrganizationTaxIdAsVatId` tinyint(1) NOT NULL DEFAULT '0',
  `orderReferenceFormat` varchar(255) DEFAULT NULL,
  `freeOrderPaymentStrategy` varchar(255) DEFAULT 'complete',
  `minimumTotalPriceStrategy` varchar(255) DEFAULT 'default',
  `sortOrder` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_stores`
--

LOCK TABLES `commerce_stores` WRITE;
/*!40000 ALTER TABLE `commerce_stores` DISABLE KEYS */;
INSERT INTO `commerce_stores` VALUES (1,'Primary','primary',1,'EUR',0,0,0,0,0,0,0,0,0,0,0,'{{number[:7]}}','complete','default',99,'2024-07-02 17:30:54','2024-07-02 18:30:19','ac75e754-1dde-4b93-aeb9-e267f370616b');
/*!40000 ALTER TABLE `commerce_stores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_storesettings`
--

DROP TABLE IF EXISTS `commerce_storesettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_storesettings` (
  `id` int NOT NULL,
  `locationAddressId` int DEFAULT NULL,
  `countries` text,
  `marketAddressCondition` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_codfsublqtwrgjjmrqrqaefbdxteodavakyl` (`locationAddressId`),
  CONSTRAINT `fk_codfsublqtwrgjjmrqrqaefbdxteodavakyl` FOREIGN KEY (`locationAddressId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_mbclmalkmvyiuyhcdasdmkgtgkjpdljlcnwg` FOREIGN KEY (`id`) REFERENCES `commerce_stores` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_storesettings`
--

LOCK TABLES `commerce_storesettings` WRITE;
/*!40000 ALTER TABLE `commerce_storesettings` DISABLE KEYS */;
INSERT INTO `commerce_storesettings` VALUES (1,14,NULL,NULL,'2024-07-02 18:26:45','2024-07-02 18:26:45','e8705e8b-ac90-4bc0-b5e3-862d5a941e5c');
/*!40000 ALTER TABLE `commerce_storesettings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_subscriptions`
--

DROP TABLE IF EXISTS `commerce_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_subscriptions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `planId` int DEFAULT NULL,
  `gatewayId` int DEFAULT NULL,
  `orderId` int DEFAULT NULL,
  `reference` varchar(255) NOT NULL,
  `subscriptionData` text,
  `trialDays` int NOT NULL,
  `nextPaymentDate` datetime DEFAULT NULL,
  `hasStarted` tinyint(1) NOT NULL DEFAULT '1',
  `isSuspended` tinyint(1) NOT NULL DEFAULT '0',
  `dateSuspended` datetime DEFAULT NULL,
  `isCanceled` tinyint(1) NOT NULL DEFAULT '0',
  `dateCanceled` datetime DEFAULT NULL,
  `isExpired` tinyint(1) NOT NULL DEFAULT '0',
  `dateExpired` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_gnovxavxvlfsnbhznotljoyvovybhdrlhdax` (`reference`),
  KEY `idx_ospqvrfeyxzyjvypxntyychcxtlzyuebkdar` (`dateCreated`),
  KEY `idx_xynemtmatiqyiktyfvrqqwzxdadlpzzclysc` (`dateExpired`),
  KEY `idx_vquqdrpqomykexykvvcpzmlbcuanjzfvtzjc` (`gatewayId`),
  KEY `idx_bfqfdcwbjrfdkxzkigprqvtpxcqbdficfvch` (`nextPaymentDate`),
  KEY `idx_twgvmgsbunpyvhufsbojetmiqxfgukuruaqx` (`planId`),
  KEY `idx_mvoozuvhleeeqrytdxutxmyxkuwmkzxodygt` (`userId`),
  KEY `fk_vcmixvoqmuvhgpzgkewfqpimlpbpjuyfdjgq` (`orderId`),
  CONSTRAINT `fk_clfmqwuklgecqudfbqfidnjiphbdsptocclz` FOREIGN KEY (`gatewayId`) REFERENCES `commerce_gateways` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_dqtbrdxplqomrivxggojcujwshjemyzbfrkx` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_gdtrxxkksfhwhisgsgvfqpjtgimueioazvio` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sidejkiunjgqtajheohyuvcwbwhzjolfzlah` FOREIGN KEY (`planId`) REFERENCES `commerce_plans` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_vcmixvoqmuvhgpzgkewfqpimlpbpjuyfdjgq` FOREIGN KEY (`orderId`) REFERENCES `commerce_orders` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_subscriptions`
--

LOCK TABLES `commerce_subscriptions` WRITE;
/*!40000 ALTER TABLE `commerce_subscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `commerce_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_taxcategories`
--

DROP TABLE IF EXISTS `commerce_taxcategories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_taxcategories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `default` tinyint(1) NOT NULL DEFAULT '0',
  `dateDeleted` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_taxcategories`
--

LOCK TABLES `commerce_taxcategories` WRITE;
/*!40000 ALTER TABLE `commerce_taxcategories` DISABLE KEYS */;
INSERT INTO `commerce_taxcategories` VALUES (1,'General','general',NULL,1,NULL,'2024-07-02 17:30:54','2024-07-02 17:30:54','1828ea12-0445-45eb-8dfd-3b6e5de3537d');
/*!40000 ALTER TABLE `commerce_taxcategories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_taxrates`
--

DROP TABLE IF EXISTS `commerce_taxrates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_taxrates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `storeId` int NOT NULL,
  `taxZoneId` int DEFAULT NULL,
  `isEverywhere` tinyint(1) NOT NULL DEFAULT '1',
  `taxCategoryId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) DEFAULT NULL,
  `rate` decimal(14,10) NOT NULL,
  `include` tinyint(1) NOT NULL DEFAULT '0',
  `isVat` tinyint(1) NOT NULL DEFAULT '0',
  `removeIncluded` tinyint(1) NOT NULL DEFAULT '0',
  `removeVatIncluded` tinyint(1) NOT NULL DEFAULT '0',
  `taxable` enum('purchasable','price','shipping','price_shipping','order_total_shipping','order_total_price') NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_mqguddchopxifcpfetdvhkzwfdunqpcgwunf` (`storeId`),
  KEY `idx_tuerffjhdomwlvalafldlgtwpaxhtnuijznr` (`taxCategoryId`),
  KEY `idx_mnehplrujykjaniasovlziweyiiqukyyhcuo` (`taxZoneId`),
  CONSTRAINT `fk_ixvosfmfyesmubrssdxeuzntzkkdabdzmfte` FOREIGN KEY (`taxZoneId`) REFERENCES `commerce_taxzones` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_wctltxfarmjxmnygvlqbbttrvfltvdqtavtj` FOREIGN KEY (`taxCategoryId`) REFERENCES `commerce_taxcategories` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_ziwksygoxxatxnemrnpdtpcllgecrlgqrbit` FOREIGN KEY (`storeId`) REFERENCES `commerce_stores` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_taxrates`
--

LOCK TABLES `commerce_taxrates` WRITE;
/*!40000 ALTER TABLE `commerce_taxrates` DISABLE KEYS */;
/*!40000 ALTER TABLE `commerce_taxrates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_taxzones`
--

DROP TABLE IF EXISTS `commerce_taxzones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_taxzones` (
  `id` int NOT NULL AUTO_INCREMENT,
  `storeId` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `condition` text,
  `default` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_towzayoizphdimmndzfsuvbmejjkgwrjzjez` (`name`),
  KEY `idx_jhqlezhqoxrxvefbiwciqqffmlmrzcezlohl` (`storeId`),
  CONSTRAINT `fk_ctlywbfqxoyzeyterwoxszyfwmdgltcnwvan` FOREIGN KEY (`storeId`) REFERENCES `commerce_stores` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_taxzones`
--

LOCK TABLES `commerce_taxzones` WRITE;
/*!40000 ALTER TABLE `commerce_taxzones` DISABLE KEYS */;
/*!40000 ALTER TABLE `commerce_taxzones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_transactions`
--

DROP TABLE IF EXISTS `commerce_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_transactions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `orderId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `gatewayId` int DEFAULT NULL,
  `userId` int DEFAULT NULL,
  `hash` varchar(32) DEFAULT NULL,
  `type` enum('authorize','capture','purchase','refund') NOT NULL,
  `amount` decimal(14,4) DEFAULT NULL,
  `paymentAmount` decimal(14,4) DEFAULT NULL,
  `currency` varchar(255) DEFAULT NULL,
  `paymentCurrency` varchar(255) DEFAULT NULL,
  `paymentRate` decimal(14,4) DEFAULT NULL,
  `status` enum('pending','redirect','success','failed','processing') NOT NULL,
  `reference` varchar(255) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `message` text,
  `note` mediumtext,
  `response` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bhlhcssgaoqszrqbztdwwseujalrftmfskhl` (`gatewayId`),
  KEY `idx_lrvhwhttzhdonlqoszuwwriejiooyidcyrtd` (`orderId`),
  KEY `idx_njgqlqhjsvynbxftfgnzrlufeofahhwloiyd` (`parentId`),
  KEY `idx_dthujufjpsduffiowgjhdkhdecifwinuxdzs` (`userId`),
  KEY `idx_fqifarrqjfuaznntcatyzcixxphdygqrqxxt` (`hash`),
  CONSTRAINT `fk_dmakagatyaxlzscwebstchpryadjaedptauo` FOREIGN KEY (`userId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_jfkrccaavrybdrdssabrxdqvvcxcqhzeflzf` FOREIGN KEY (`parentId`) REFERENCES `commerce_transactions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_xikphugjwtwgptsgngfqlhlruqvbpdsopiqs` FOREIGN KEY (`gatewayId`) REFERENCES `commerce_gateways` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_yykkgftmniontmfghhykempwznupqjzlwgwr` FOREIGN KEY (`orderId`) REFERENCES `commerce_orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_transactions`
--

LOCK TABLES `commerce_transactions` WRITE;
/*!40000 ALTER TABLE `commerce_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `commerce_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_transfers`
--

DROP TABLE IF EXISTS `commerce_transfers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_transfers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `transferStatus` enum('draft','pending','partial','received') NOT NULL,
  `originLocationId` int DEFAULT NULL,
  `destinationLocationId` int DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_jnnmrdwsjljrqxxdujkhqikpwbeeuomopevj` (`destinationLocationId`),
  KEY `idx_uulmaplsyihiwbeobiyieqgugckpxmwjmdrv` (`originLocationId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_transfers`
--

LOCK TABLES `commerce_transfers` WRITE;
/*!40000 ALTER TABLE `commerce_transfers` DISABLE KEYS */;
/*!40000 ALTER TABLE `commerce_transfers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_transfers_inventoryitems`
--

DROP TABLE IF EXISTS `commerce_transfers_inventoryitems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_transfers_inventoryitems` (
  `id` int NOT NULL AUTO_INCREMENT,
  `transferId` int NOT NULL,
  `inventoryItemId` int NOT NULL,
  `quantity` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_fyfxphhwpjgzdompiugsewmpeymgjogavuow` (`inventoryItemId`),
  KEY `idx_akrpupiawojlmyocofspckkcmsdxbhxvfejy` (`transferId`),
  CONSTRAINT `fk_metkiaqwltxgioaijhqelqcopaekoidjmall` FOREIGN KEY (`inventoryItemId`) REFERENCES `commerce_inventoryitems` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ytsgdugqxxllthfasgwcdbfoixwhusmzpfcn` FOREIGN KEY (`transferId`) REFERENCES `commerce_inventoryitems` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_transfers_inventoryitems`
--

LOCK TABLES `commerce_transfers_inventoryitems` WRITE;
/*!40000 ALTER TABLE `commerce_transfers_inventoryitems` DISABLE KEYS */;
/*!40000 ALTER TABLE `commerce_transfers_inventoryitems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commerce_variants`
--

DROP TABLE IF EXISTS `commerce_variants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commerce_variants` (
  `id` int NOT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `isDefault` tinyint(1) NOT NULL DEFAULT '0',
  `sortOrder` int DEFAULT NULL,
  `deletedWithProduct` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qplwjncalzqwgqgkinicusknmqxjzlzbfgbg` (`primaryOwnerId`),
  CONSTRAINT `fk_ahsqsiywgnmrdpjcmmkwybfvjxjyvkekbjxv` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xayczxdaaljuatbqijikulqmmvxydipcxrmc` FOREIGN KEY (`primaryOwnerId`) REFERENCES `commerce_products` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commerce_variants`
--

LOCK TABLES `commerce_variants` WRITE;
/*!40000 ALTER TABLE `commerce_variants` DISABLE KEYS */;
INSERT INTO `commerce_variants` VALUES (13,12,1,NULL,0,'2024-07-02 18:04:13','2024-07-02 18:04:13','190b7a11-81ff-467f-b1ac-795e05d5351d'),(17,16,1,NULL,0,'2024-07-02 18:29:55','2024-07-02 18:30:05','f317f118-92fa-4c4f-96ee-d4e8bbfed249');
/*!40000 ALTER TABLE `commerce_variants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craftidtokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_kfdhvrbrcdgxncesiauomrhrnwfdvewegeod` (`userId`),
  CONSTRAINT `fk_kfdhvrbrcdgxncesiauomrhrnwfdvewegeod` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deprecationerrors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint unsigned DEFAULT NULL,
  `message` text,
  `traces` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_iyhbvpyavxdkizodxtpjelhtintpuhotqrax` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drafts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `creatorId` int DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `notes` text,
  `trackChanges` tinyint(1) NOT NULL DEFAULT '0',
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_ojhkevuoxvrtvduwxnhzfwdnxwfdauzfmxfm` (`creatorId`,`provisional`),
  KEY `idx_iqehpzifcpeepuawzkicjdcciigxlcalswxj` (`saved`),
  KEY `fk_ulgfapvktxmskkvvsrgxhorrqcyprqtrmciy` (`canonicalId`),
  CONSTRAINT `fk_kovzynbnpjnjdsdtmdnltgvzbyycxdqbegmj` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ulgfapvktxmskkvvsrgxhorrqcyprqtrmciy` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elementactivity`
--

DROP TABLE IF EXISTS `elementactivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elementactivity` (
  `elementId` int NOT NULL,
  `userId` int NOT NULL,
  `siteId` int NOT NULL,
  `draftId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`elementId`,`userId`,`type`),
  KEY `idx_gjztifjivzmfnoorviaqksswesdjkjsoowaw` (`elementId`,`timestamp`,`userId`),
  KEY `fk_atshlfprmxhgdqekjjidozuzgiovptvjtrcz` (`userId`),
  KEY `fk_hubktreetlhjjelvvatearrsdobaxgmttftx` (`siteId`),
  KEY `fk_spcmvmpgkxswxcibllfcoysstrmpyjqdbwpu` (`draftId`),
  CONSTRAINT `fk_atshlfprmxhgdqekjjidozuzgiovptvjtrcz` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_hubktreetlhjjelvvatearrsdobaxgmttftx` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_spcmvmpgkxswxcibllfcoysstrmpyjqdbwpu` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wrdqgyfvvbuvdrkpxrkqwzlvgcivaqtvfcli` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elementactivity`
--

LOCK TABLES `elementactivity` WRITE;
/*!40000 ALTER TABLE `elementactivity` DISABLE KEYS */;
INSERT INTO `elementactivity` VALUES (1,1,1,NULL,'view','2024-07-19 08:06:30'),(2,1,1,NULL,'view','2024-07-02 17:55:31'),(3,1,1,NULL,'view','2024-07-02 18:00:40'),(6,1,1,NULL,'view','2024-07-02 18:00:48'),(12,1,1,NULL,'view','2024-07-02 18:04:20'),(16,1,1,NULL,'save','2024-07-02 18:30:05'),(16,1,1,NULL,'view','2024-07-19 07:59:50'),(17,1,1,NULL,'save','2024-07-02 18:30:01');
/*!40000 ALTER TABLE `elementactivity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `draftId` int DEFAULT NULL,
  `revisionId` int DEFAULT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_nqnjsemzmpvybvpmkrwdaxltbyerrftoudym` (`dateDeleted`),
  KEY `idx_ywyrujgblepfiwfrozircnkothwwcjgzuopm` (`fieldLayoutId`),
  KEY `idx_lftazzogpgqbzxqiqlutplubynjipwypvpln` (`type`),
  KEY `idx_sctvlivwpoqotjuimvycmfftlrwuitpszrdi` (`enabled`),
  KEY `idx_rnhdqjqznfjabrnclesjtjhundekzhdubimx` (`canonicalId`),
  KEY `idx_nkpqttwnrukacxjlhkgfbdhjqtdgeogtuuen` (`archived`,`dateCreated`),
  KEY `idx_mkcgqyfjccdbsvluxaaslojdnsqsuwsaocov` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `idx_etrufjitegbifwljrqigmaclushbmmtaapvc` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`,`enabled`),
  KEY `fk_kmbuzyszxgnwemljykvzeiltleyijixxiawr` (`draftId`),
  KEY `fk_wmkerawxeffrwzkmsiaqnhuknwcfvtzjyrit` (`revisionId`),
  CONSTRAINT `fk_kmbuzyszxgnwemljykvzeiltleyijixxiawr` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wizxnnlbdnhwfodfxbvmfikengmhapjfsjpa` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_wmkerawxeffrwzkmsiaqnhuknwcfvtzjyrit` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zbxukkglnlvdcyvothzprhtmqenlwwjrcbml` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
INSERT INTO `elements` VALUES (1,NULL,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2024-07-02 17:29:02','2024-07-02 17:29:02',NULL,NULL,NULL,'17d337a6-401d-49b1-96ef-6af2f4af110d'),(2,NULL,NULL,NULL,1,'craft\\commerce\\elements\\Product',1,0,'2024-07-02 17:49:29','2024-07-02 18:04:40',NULL,'2024-07-02 18:04:40',NULL,'86fe13cd-c36e-4f1d-a287-a28a489ac900'),(3,NULL,NULL,NULL,1,'craft\\commerce\\elements\\Product',1,0,'2024-07-02 17:49:53','2024-07-02 18:04:40',NULL,'2024-07-02 18:04:40',NULL,'2cd650c5-cc21-45ab-8210-684bde75b6bc'),(4,NULL,NULL,NULL,1,'craft\\commerce\\elements\\Product',1,0,'2024-07-02 17:53:23','2024-07-02 18:04:40',NULL,'2024-07-02 18:04:40',NULL,'1ca2dd74-b7df-4066-96ba-32938a0b6e3c'),(5,NULL,NULL,NULL,1,'craft\\commerce\\elements\\Product',1,0,'2024-07-02 17:54:59','2024-07-02 18:04:40',NULL,'2024-07-02 18:04:40',NULL,'29167984-b2fe-453b-bf2e-262b071ced3d'),(6,NULL,NULL,NULL,1,'craft\\commerce\\elements\\Product',1,0,'2024-07-02 18:00:25','2024-07-02 18:04:40',NULL,'2024-07-02 18:04:40',NULL,'58956cde-6aa5-4453-a7af-d68bed26a5da'),(7,NULL,NULL,NULL,1,'craft\\commerce\\elements\\Product',1,0,'2024-07-02 18:01:14','2024-07-02 18:04:40',NULL,'2024-07-02 18:04:40',NULL,'0ead3079-8bf7-4bb9-9876-f77d3a48ae22'),(8,NULL,NULL,NULL,1,'craft\\commerce\\elements\\Product',1,0,'2024-07-02 18:02:46','2024-07-02 18:04:40',NULL,'2024-07-02 18:04:40',NULL,'520f879f-e0ce-467a-a210-092988c9e9d0'),(9,NULL,NULL,NULL,1,'craft\\commerce\\elements\\Product',1,0,'2024-07-02 18:03:00','2024-07-02 18:04:40',NULL,'2024-07-02 18:04:40',NULL,'4139da35-9bb5-4438-b38f-71bfc6bf1687'),(10,NULL,NULL,NULL,1,'craft\\commerce\\elements\\Product',1,0,'2024-07-02 18:03:41','2024-07-02 18:04:40',NULL,'2024-07-02 18:04:40',NULL,'1ef68417-2b06-4827-bcf2-bbd8e45643b4'),(11,NULL,NULL,NULL,1,'craft\\commerce\\elements\\Product',1,0,'2024-07-02 18:03:55','2024-07-02 18:04:40',NULL,'2024-07-02 18:04:40',NULL,'c6eb5cb8-c292-49ab-8021-9b9e423e75d3'),(12,NULL,NULL,NULL,1,'craft\\commerce\\elements\\Product',1,0,'2024-07-02 18:04:13','2024-07-02 18:04:40',NULL,'2024-07-02 18:04:40',NULL,'60f2925d-5f14-48bf-9d3b-dbda6904fb28'),(13,NULL,NULL,NULL,2,'craft\\commerce\\elements\\Variant',1,0,'2024-07-02 18:04:13','2024-07-02 18:04:40',NULL,'2024-07-02 18:04:40',1,'e309360b-900a-4da9-83f0-7d893eb83ac2'),(14,NULL,NULL,NULL,NULL,'craft\\elements\\Address',1,0,'2024-07-02 18:26:45','2024-07-02 18:26:45',NULL,NULL,NULL,'bf4c5f50-9929-41f8-9684-e4104da3f28a'),(16,NULL,NULL,NULL,1,'craft\\commerce\\elements\\Product',1,0,'2024-07-02 18:29:52','2024-07-02 18:30:05',NULL,NULL,NULL,'37f93cfa-1e51-4394-977d-e14a85b4c35f'),(17,NULL,NULL,NULL,2,'craft\\commerce\\elements\\Variant',1,0,'2024-07-02 18:29:55','2024-07-02 18:30:05',NULL,NULL,NULL,'a21dc2fc-7bd2-42ac-88d4-37fa2ec3792e'),(18,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2024-07-19 08:14:00','2024-07-19 08:14:00',NULL,NULL,NULL,'0cfb2e3b-12b4-4ce5-b937-7d06f3850fc3'),(19,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2024-07-19 08:14:03','2024-07-19 08:14:03',NULL,NULL,NULL,'5895c4b6-630d-4ef7-a707-66a07acab69e'),(20,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2024-07-19 08:14:03','2024-07-19 08:14:03',NULL,NULL,NULL,'036eb5ce-f899-4b16-827a-a36ef83b5353'),(21,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2024-07-19 08:14:03','2024-07-19 08:14:03',NULL,NULL,NULL,'4eb1c88c-8597-44eb-8929-d2ab3a0fd6ab');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_bulkops`
--

DROP TABLE IF EXISTS `elements_bulkops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_bulkops` (
  `elementId` int NOT NULL,
  `key` char(10) NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`elementId`,`key`),
  KEY `idx_rkumiqoytziklegevoxyusexscpdufjcluuw` (`timestamp`),
  CONSTRAINT `fk_zplohighsshysgtfukyykavcyyluwuoferqe` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_bulkops`
--

LOCK TABLES `elements_bulkops` WRITE;
/*!40000 ALTER TABLE `elements_bulkops` DISABLE KEYS */;
/*!40000 ALTER TABLE `elements_bulkops` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_owners`
--

DROP TABLE IF EXISTS `elements_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_owners` (
  `elementId` int NOT NULL,
  `ownerId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`elementId`,`ownerId`),
  KEY `fk_qyhvqbmbnytyyfhehpihabeohzecxlhsqjui` (`ownerId`),
  CONSTRAINT `fk_bqyntoxaviohpbiaopbsuxcnlclcvlhqiync` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qyhvqbmbnytyyfhehpihabeohzecxlhsqjui` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_owners`
--

LOCK TABLES `elements_owners` WRITE;
/*!40000 ALTER TABLE `elements_owners` DISABLE KEYS */;
INSERT INTO `elements_owners` VALUES (13,12,1),(17,16,1);
/*!40000 ALTER TABLE `elements_owners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `content` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_hgkqnwuxiqhowkyycfglwmmmnulbntvhfxsb` (`elementId`,`siteId`),
  KEY `idx_mcqdecexshpxcuhtjzgqssuocsgfnffwqhap` (`siteId`),
  KEY `idx_nhtjvjwehyaglowurohzbjnaewxxtdlwnjof` (`title`,`siteId`),
  KEY `idx_mfctyuunudarcfqhmapnzyaizgsbevysmvmk` (`slug`,`siteId`),
  KEY `idx_isktcqgplzvvftshdrzeglwzmuvycoizznwh` (`enabled`),
  KEY `idx_fmlmzpfqxxfltbxabffmpagdkbugwtlbdhvt` (`uri`,`siteId`),
  CONSTRAINT `fk_kcgecjgakrticddpaygfavhtsjgyyevxcptd` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mmjhwpseyminshongozhihtbjmkkewfdyyns` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
INSERT INTO `elements_sites` VALUES (1,1,1,NULL,NULL,NULL,NULL,1,'2024-07-02 17:29:02','2024-07-02 17:29:02','ac0012fa-b78e-43af-9b5c-81002db7d164'),(2,2,1,'My test product - 1719942569','my-test-product-1719942569','general/my-test-product-1719942569',NULL,1,'2024-07-02 17:49:29','2024-07-02 17:49:29','03d03c9b-fea0-4d66-8fb6-95dcc22c3d09'),(3,3,1,'My test product - 1719942593','my-test-product-1719942593','general/my-test-product-1719942593',NULL,1,'2024-07-02 17:49:53','2024-07-02 17:49:53','f15cb7c1-8695-4f58-9d9f-23df6c7e58bc'),(4,4,1,'My test product - 1719942803','my-test-product-1719942803','general/my-test-product-1719942803',NULL,1,'2024-07-02 17:53:23','2024-07-02 17:53:23','bed9d516-2dad-4b21-8397-c024266d7e5d'),(5,5,1,'My test product - 1719942899','my-test-product-1719942899','general/my-test-product-1719942899',NULL,1,'2024-07-02 17:54:59','2024-07-02 17:54:59','a8ed5c63-0ae2-46e1-8d1e-8cac3d00b94d'),(6,6,1,'My test product - 1719943225','my-test-product-1719943225','general/my-test-product-1719943225',NULL,1,'2024-07-02 18:00:25','2024-07-02 18:00:25','9956ded1-45af-433f-9cdc-d53c303bede5'),(7,7,1,'My test product - 1719943274','my-test-product-1719943274','general/my-test-product-1719943274',NULL,1,'2024-07-02 18:01:14','2024-07-02 18:01:14','ad192cba-563e-4724-b8f6-923dbf35a1a8'),(8,8,1,'My test product - 1719943366','my-test-product-1719943366','general/my-test-product-1719943366',NULL,1,'2024-07-02 18:02:46','2024-07-02 18:02:46','038d57e9-bd73-468b-a23a-ffb30074bcf6'),(9,9,1,'My test product - 1719943380','my-test-product-1719943380','general/my-test-product-1719943380',NULL,1,'2024-07-02 18:03:00','2024-07-02 18:03:00','6f2df900-0985-4181-8a67-5408c80a4282'),(10,10,1,'My test product - 1719943421','my-test-product-1719943421','general/my-test-product-1719943421',NULL,1,'2024-07-02 18:03:41','2024-07-02 18:03:41','48e18444-6add-4496-9468-912f2909f9de'),(11,11,1,'My test product - 1719943435','my-test-product-1719943435','general/my-test-product-1719943435',NULL,1,'2024-07-02 18:03:55','2024-07-02 18:03:55','a5443174-b794-4a74-9ba4-35e396d665a7'),(12,12,1,'My test product - 1719943453','my-test-product-1719943453','general/my-test-product-1719943453',NULL,1,'2024-07-02 18:04:13','2024-07-02 18:04:13','05b32cc5-5afb-4ea1-9158-7e719b872848'),(13,13,1,'My test variant - 1719943453',NULL,NULL,NULL,1,'2024-07-02 18:04:13','2024-07-02 18:04:13','3b0a6f16-bd2d-4024-84f7-99a335dc6828'),(14,14,1,'Store',NULL,NULL,NULL,1,'2024-07-02 18:26:45','2024-07-02 18:26:45','0473e185-367b-4be0-9b6e-7ba983e24beb'),(16,16,1,'test','test','general/test','{\"6e43c6c9-f5a4-42a8-a1de-161847fc7b69\": \"123\"}',1,'2024-07-02 18:29:52','2024-07-02 18:30:05','90855ed3-1f6f-43cf-ba9c-a2a2c0335a4c'),(17,17,1,'test123','__temp_nbwkrmwnrbyvbreyfpawtzfuoigkdytiviuq',NULL,NULL,1,'2024-07-02 18:29:55','2024-07-02 18:30:01','e4a6b5ba-2909-4a91-acf5-1d20af7fa391'),(18,18,1,'test','test','product-categories/test',NULL,1,'2024-07-19 08:14:00','2024-07-19 09:42:05','d175891e-d000-43cd-9d86-ee2e44d1312d'),(19,19,1,'test','test-2','product-categories/test-2',NULL,1,'2024-07-19 08:14:03','2024-07-19 09:42:05','9e4aec65-184f-4bcb-b382-ae48b679e363'),(20,20,1,'test','test-3','product-categories/test-3',NULL,1,'2024-07-19 08:14:03','2024-07-19 09:42:05','5fba4e17-02fe-4ebf-8587-40cb48aa1a64'),(21,21,1,'test','test-4','product-categories/test-4',NULL,1,'2024-07-19 08:14:03','2024-07-19 09:42:05','9741af49-4e87-420c-b46c-d5b9d1155536');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries` (
  `id` int NOT NULL,
  `sectionId` int DEFAULT NULL,
  `parentId` int DEFAULT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `typeId` int NOT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_lnxkfviimzddffwocdptxjkojmpyxskegfkd` (`postDate`),
  KEY `idx_lelvjglpdbcxgjcgcuagepqhtfjsuysxiqbb` (`expiryDate`),
  KEY `idx_nbhuxefedbzahsabzzulllnvtlezuknatcam` (`sectionId`),
  KEY `idx_yezcjxsukrajmqcajknwpfhflxizpkoillzv` (`typeId`),
  KEY `idx_yoqowdrjpxndnlwsesntympcbpywinjcssts` (`primaryOwnerId`),
  KEY `idx_rzwofleohwouzkyjgxkusthppoixouumlovk` (`fieldId`),
  KEY `fk_ppdzqzivxljaaywqdzfyshpzhdeyqfwxakjr` (`parentId`),
  CONSTRAINT `fk_cnoijhmflalfgiahxukhhtsmpdnfulepodyh` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ctxtntkzdjuypvtmevdclczkfgeoupkqtudu` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ppdzqzivxljaaywqdzfyshpzhdeyqfwxakjr` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_rlcegwslqkamrcyukicbrzoedjiebcubhbvg` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_smonrzsuvflkdxcnfeqijuafbvmvjtoztlwk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wtlpbywdysqptwgpivrkymaadftvkcggioij` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
INSERT INTO `entries` VALUES (18,1,NULL,NULL,NULL,1,'2024-07-19 08:14:00',NULL,NULL,'2024-07-19 08:14:00','2024-07-19 08:14:00'),(19,1,NULL,NULL,NULL,1,'2024-07-19 08:14:00',NULL,NULL,'2024-07-19 08:14:03','2024-07-19 08:14:03'),(20,1,NULL,NULL,NULL,1,'2024-07-19 08:14:00',NULL,NULL,'2024-07-19 08:14:03','2024-07-19 08:14:03'),(21,1,NULL,NULL,NULL,1,'2024-07-19 08:14:00',NULL,NULL,'2024-07-19 08:14:03','2024-07-19 08:14:03');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entries_authors`
--

DROP TABLE IF EXISTS `entries_authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries_authors` (
  `entryId` int NOT NULL,
  `authorId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`entryId`,`authorId`),
  KEY `idx_sfcdiefsrcufocbgimwdfudmjayguntrewlo` (`authorId`),
  KEY `idx_hampfaexjdsyoijnxgvmpzmxrjqacsjcyozh` (`entryId`,`sortOrder`),
  CONSTRAINT `fk_kkamobodqrdjpargyoelqoeekmrrpzmqiubz` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_uzeannftxaplkadgnlvxxrsuimiwjvfpdvnu` FOREIGN KEY (`entryId`) REFERENCES `entries` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entries_authors`
--

LOCK TABLES `entries_authors` WRITE;
/*!40000 ALTER TABLE `entries_authors` DISABLE KEYS */;
INSERT INTO `entries_authors` VALUES (18,1,1),(19,1,1),(20,1,1),(21,1,1);
/*!40000 ALTER TABLE `entries_authors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entrytypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `titleFormat` varchar(255) DEFAULT NULL,
  `showSlugField` tinyint(1) DEFAULT '1',
  `slugTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `slugTranslationKeyFormat` text,
  `showStatusField` tinyint(1) DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_zxrbtsiofwhrsenvzmbxuvfpkghvrkjmiuti` (`fieldLayoutId`),
  KEY `idx_woljqxtaoraqdpigxuhkwwldrvmqrhnqqllk` (`dateDeleted`),
  CONSTRAINT `fk_xxxofrewhvhwlhqlhlqopqomjltmxohlfowz` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
INSERT INTO `entrytypes` VALUES (1,3,'Product Category','productCategory','',NULL,1,'site',NULL,'',0,'site',NULL,0,'2024-07-19 07:59:17','2024-07-19 07:59:17',NULL,'96c3a328-d0ec-483b-82b3-5e9cbf59a3cd');
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayouts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `config` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_voozcjvgahshupooaconqroehndlepzllxrn` (`dateDeleted`),
  KEY `idx_apjowwevfhaenjpqmrwtyxypgtbrfzwqkebd` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
INSERT INTO `fieldlayouts` VALUES (1,'craft\\commerce\\elements\\Product','{\"tabs\": [{\"uid\": \"5ff418e5-3c49-4075-81e9-f5aa31f9d7bd\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"aae4208f-eba9-481b-b63e-a40000beed42\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\commerce\\\\fieldlayoutelements\\\\ProductTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"id\": null, \"tip\": null, \"uid\": \"7f70031b-f473-41ac-b37c-f08c1333fa90\", \"type\": \"craft\\\\commerce\\\\fieldlayoutelements\\\\VariantsField\", \"label\": null, \"warning\": null, \"required\": false, \"attribute\": \"variants\", \"mandatory\": true, \"requirable\": false, \"orientation\": null, \"instructions\": null, \"translatable\": false, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"6e43c6c9-f5a4-42a8-a1de-161847fc7b69\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": \"Custom Required Field 1\", \"width\": 100, \"handle\": \"customRequiredField1\", \"warning\": null, \"fieldUid\": \"c8c46842-af9f-4880-aebc-26583c15b659\", \"required\": true, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"80507a11-a09b-43c2-9a5c-35ebea97a44a\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"376223de-9e80-4a0d-84ea-8877242918e1\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-07-02 17:37:32','2024-07-19 08:00:46',NULL,'446e6dcb-4af8-4959-b422-616cdd4338b7'),(2,'craft\\commerce\\elements\\Variant','{\"tabs\": [{\"uid\": \"cdf25b1e-c3d5-498a-abfb-6788704e9ca5\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"d10c9eb9-bfb0-4d40-9134-79580b30c67b\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\commerce\\\\fieldlayoutelements\\\\VariantTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"id\": null, \"tip\": null, \"uid\": \"eb0d228f-dc71-44ab-a790-66177d47acb4\", \"type\": \"craft\\\\commerce\\\\fieldlayoutelements\\\\PurchasableSkuField\", \"label\": \"SKU\", \"width\": 100, \"warning\": null, \"required\": true, \"attribute\": \"sku\", \"mandatory\": true, \"requirable\": false, \"orientation\": null, \"instructions\": null, \"translatable\": false, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"id\": null, \"tip\": null, \"uid\": \"66707687-4295-45a1-bc8e-a8568651ffd5\", \"type\": \"craft\\\\commerce\\\\fieldlayoutelements\\\\PurchasablePriceField\", \"label\": \"__blank__\", \"width\": 100, \"warning\": null, \"required\": true, \"attribute\": \"price\", \"mandatory\": true, \"requirable\": false, \"orientation\": null, \"instructions\": null, \"translatable\": false, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"id\": null, \"tip\": null, \"uid\": \"cc719aab-77be-4243-be19-d6a116800298\", \"type\": \"craft\\\\commerce\\\\fieldlayoutelements\\\\PurchasableStockField\", \"label\": \"Inventory\", \"width\": 100, \"warning\": null, \"required\": true, \"attribute\": \"stock\", \"mandatory\": true, \"requirable\": false, \"orientation\": null, \"instructions\": null, \"translatable\": false, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"id\": null, \"tip\": null, \"uid\": \"9dce4367-4cb3-4a11-b0a7-8d8484ea0d6a\", \"type\": \"craft\\\\commerce\\\\fieldlayoutelements\\\\PurchasableAvailableForPurchaseField\", \"label\": \"Available for purchase\", \"width\": 100, \"warning\": null, \"required\": true, \"attribute\": \"availableForPurchase\", \"mandatory\": true, \"requirable\": false, \"orientation\": null, \"instructions\": null, \"translatable\": false, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"id\": null, \"tip\": null, \"uid\": \"812a5893-9d93-4d42-8476-f565ddb10526\", \"type\": \"craft\\\\commerce\\\\fieldlayoutelements\\\\PurchasableAllowedQtyField\", \"label\": \"Allowed Qty\", \"width\": 100, \"warning\": null, \"required\": false, \"attribute\": \"allowedQty\", \"mandatory\": true, \"requirable\": false, \"orientation\": null, \"instructions\": null, \"translatable\": false, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"id\": null, \"tip\": null, \"uid\": \"13cb3f56-a613-4cdf-8afd-76392d095d1d\", \"type\": \"craft\\\\commerce\\\\fieldlayoutelements\\\\PurchasableFreeShippingField\", \"label\": \"Free Shipping\", \"width\": 100, \"warning\": null, \"required\": true, \"attribute\": \"freeShipping\", \"mandatory\": true, \"requirable\": false, \"orientation\": null, \"instructions\": null, \"translatable\": false, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"id\": null, \"tip\": null, \"uid\": \"914b039e-12be-4c21-8822-0e9c581e9dc5\", \"type\": \"craft\\\\commerce\\\\fieldlayoutelements\\\\PurchasablePromotableField\", \"label\": \"Promotable\", \"width\": 100, \"warning\": null, \"required\": true, \"attribute\": \"promotable\", \"mandatory\": true, \"requirable\": false, \"orientation\": null, \"instructions\": null, \"translatable\": false, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"id\": null, \"tip\": null, \"uid\": \"6c5b8306-6435-44bb-b04d-4921b089dc30\", \"type\": \"craft\\\\commerce\\\\fieldlayoutelements\\\\PurchasableDimensionsField\", \"label\": \"Dimensions\", \"width\": 100, \"warning\": null, \"required\": false, \"attribute\": \"dimensions\", \"mandatory\": true, \"requirable\": false, \"orientation\": null, \"instructions\": null, \"translatable\": false, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"id\": null, \"tip\": null, \"uid\": \"4f8453e9-e685-46e8-aa55-d21fea612d1e\", \"type\": \"craft\\\\commerce\\\\fieldlayoutelements\\\\PurchasableWeightField\", \"label\": \"Weight\", \"width\": 100, \"warning\": null, \"required\": false, \"attribute\": \"weight\", \"mandatory\": true, \"requirable\": false, \"orientation\": null, \"instructions\": null, \"translatable\": false, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}]}','2024-07-02 17:37:32','2024-07-02 17:37:32',NULL,'993b0a3a-38ca-4d3f-b382-72807d3fb558'),(3,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"78cd103a-cd04-48a9-983e-fbc7fc72241b\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"7ca94726-5e2a-4cdc-8918-497541e7a5f8\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"d1e71e52-bd18-4e2c-85b0-96e7d888de5b\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": \"Subline\", \"width\": 100, \"handle\": \"subline\", \"warning\": null, \"fieldUid\": \"c8c46842-af9f-4880-aebc-26583c15b659\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-07-19 07:59:17','2024-07-19 07:59:17',NULL,'9c9ebbe4-6a5d-4400-a887-adf6c96acedc');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `columnSuffix` char(8) DEFAULT NULL,
  `instructions` text,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_grprhygnipmrdwjyxcomxifshzumqsiimsco` (`handle`,`context`),
  KEY `idx_kzwitqlxtsatpabapnerbgwqokzlizgwghpt` (`context`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
INSERT INTO `fields` VALUES (1,'Common Plain Text','commonPlainText','global',NULL,NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-07-02 17:50:50','2024-07-02 17:50:50','c8c46842-af9f-4880-aebc-26583c15b659'),(2,'Product Categories','productCategories','global',NULL,'Select one product category, multiple categories are not supported here.\r\n\r\n',0,'site',NULL,'craft\\fields\\Entries','{\"allowSelfRelations\":false,\"branchLimit\":1,\"localizeRelations\":false,\"maintainHierarchy\":true,\"maxRelations\":null,\"minRelations\":null,\"selectionLabel\":null,\"showCardsInGrid\":false,\"showSiteMenu\":false,\"sources\":[\"section:cdec25d5-684f-41ff-8fc7-f0935d020549\"],\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"list\"}','2024-07-19 08:00:42','2024-07-19 08:00:42','376223de-9e80-4a0d-84ea-8877242918e1');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `globalsets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_oyckaixzxnqsmamposylzcghazltjwkklbfa` (`name`),
  KEY `idx_qwybnxbcrdkvahjcvgpbdsqadeulpxjuulym` (`handle`),
  KEY `idx_zzelpgeojojvltkgtnhdjyntoedydaevgzvp` (`fieldLayoutId`),
  KEY `idx_fogftaknnprvygutavhfkcicuwlxbijqmxvh` (`sortOrder`),
  CONSTRAINT `fk_hkkrchnmcawrtuavitjdwvsbflpotbiatdqw` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_zxtvwaoipuftklryqmjbxsipsheuktbvaemw` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqlschemas`
--

DROP TABLE IF EXISTS `gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqlschemas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `scope` json DEFAULT NULL,
  `isPublic` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqlschemas`
--

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;
INSERT INTO `gqlschemas` VALUES (1,'Public Schema','[]',1,'2024-07-02 18:26:39','2024-07-02 18:26:39','0f99cee4-5957-4b55-8de9-9b03ebe0f9f8'),(2,'Private Schema','[\"sites.6fc0244d-6ccb-4cb1-b1e5-c10752c00220:read\", \"sections.cdec25d5-684f-41ff-8fc7-f0935d020549:read\", \"usergroups.everyone:read\", \"productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83:read\", \"sections.cdec25d5-684f-41ff-8fc7-f0935d020549:edit\", \"sections.cdec25d5-684f-41ff-8fc7-f0935d020549:create\", \"sections.cdec25d5-684f-41ff-8fc7-f0935d020549:save\", \"sections.cdec25d5-684f-41ff-8fc7-f0935d020549:delete\"]',0,'2024-07-19 08:01:28','2024-07-19 09:42:08','9ef8f2a9-d981-4a73-8db1-69675b452cea');
/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqltokens`
--

DROP TABLE IF EXISTS `gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqltokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lvmilpezqujqbtxjmyzpkaixwqokwpbfuezk` (`accessToken`),
  UNIQUE KEY `idx_kggbiihbunrzirdkfsweuvqsmnghyosjeeen` (`name`),
  KEY `fk_xhlfpvvbppbbiytwyiygdfeizfawtigtqgtv` (`schemaId`),
  CONSTRAINT `fk_xhlfpvvbppbbiytwyiygdfeizfawtigtqgtv` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqltokens`
--

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;
INSERT INTO `gqltokens` VALUES (1,'Private','CDwvk4kPKUBTBWsivteRLgd7DtIzcEa6',1,NULL,'2024-07-19 08:10:06',2,'2024-07-19 08:03:16','2024-07-19 08:10:06','7355bde0-4adf-4d4b-8096-0c580f06abe5');
/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransformindex`
--

DROP TABLE IF EXISTS `imagetransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransformindex` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assetId` int NOT NULL,
  `transformer` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `transformString` varchar(255) NOT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `error` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_owacjdbkreeztsqvcjssmfuthfeqocdvowql` (`assetId`,`transformString`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransformindex`
--

LOCK TABLES `imagetransformindex` WRITE;
/*!40000 ALTER TABLE `imagetransformindex` DISABLE KEYS */;
/*!40000 ALTER TABLE `imagetransformindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransforms`
--

DROP TABLE IF EXISTS `imagetransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransforms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop','letterbox') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `fill` varchar(11) DEFAULT NULL,
  `upscale` tinyint(1) NOT NULL DEFAULT '1',
  `parameterChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_esojmeymxzinddcwmdurlpliacsxlloljyti` (`name`),
  KEY `idx_ptrbyomswaywkeykkjhtncsxhbeacpdjdagx` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransforms`
--

LOCK TABLES `imagetransforms` WRITE;
/*!40000 ALTER TABLE `imagetransforms` DISABLE KEYS */;
/*!40000 ALTER TABLE `imagetransforms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `configVersion` char(12) NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
INSERT INTO `info` VALUES (1,'5.2.5','5.0.0.21',0,'qqjedndgknao','3@ajidfsfyhe','2024-07-02 17:29:02','2024-07-19 09:42:08','4e39980b-e55c-4a25-b169-d23fc9deef39');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `track` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_nhizczpzqklblbwgmoqpcswjumhzgeimbymf` (`track`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=113 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'craft','Install','2024-07-02 17:29:03','2024-07-02 17:29:03','2024-07-02 17:29:03','be971551-73bc-45d7-be60-ac59f82b2da8'),(2,'craft','m221101_115859_create_entries_authors_table','2024-07-02 17:29:03','2024-07-02 17:29:03','2024-07-02 17:29:03','1020403c-7826-4dfe-8781-1310387089d1'),(3,'craft','m221107_112121_add_max_authors_to_sections','2024-07-02 17:29:03','2024-07-02 17:29:03','2024-07-02 17:29:03','b557eaf6-5335-4e62-87c4-7aaecbeb5553'),(4,'craft','m221205_082005_translatable_asset_alt_text','2024-07-02 17:29:03','2024-07-02 17:29:03','2024-07-02 17:29:03','3cf70b81-2958-4190-9d2c-623c32c24f14'),(5,'craft','m230314_110309_add_authenticator_table','2024-07-02 17:29:03','2024-07-02 17:29:03','2024-07-02 17:29:03','7f08cbb4-d8db-4218-b76f-f806a14c1821'),(6,'craft','m230314_111234_add_webauthn_table','2024-07-02 17:29:03','2024-07-02 17:29:03','2024-07-02 17:29:03','c9b979a5-b37c-41f9-879f-8d800ad4321f'),(7,'craft','m230503_120303_add_recoverycodes_table','2024-07-02 17:29:03','2024-07-02 17:29:03','2024-07-02 17:29:03','47496983-ec0e-4221-893e-653945b638db'),(8,'craft','m230511_000000_field_layout_configs','2024-07-02 17:29:03','2024-07-02 17:29:03','2024-07-02 17:29:03','d13d7202-ae0a-4ba9-a9c2-7e46a7832bdd'),(9,'craft','m230511_215903_content_refactor','2024-07-02 17:29:03','2024-07-02 17:29:03','2024-07-02 17:29:03','8d6814a8-2504-4eb0-b91a-bee6ea4613db'),(10,'craft','m230524_000000_add_entry_type_show_slug_field','2024-07-02 17:29:03','2024-07-02 17:29:03','2024-07-02 17:29:03','e8a1dac5-6cb9-4ccd-8a50-a583b4f7ae51'),(11,'craft','m230524_000001_entry_type_icons','2024-07-02 17:29:03','2024-07-02 17:29:03','2024-07-02 17:29:03','656df1ad-82ea-45f5-b44a-728fca5c9f00'),(12,'craft','m230524_000002_entry_type_colors','2024-07-02 17:29:03','2024-07-02 17:29:03','2024-07-02 17:29:03','f6a7004d-24ab-41fa-9ec7-9587fdf73385'),(13,'craft','m230524_220029_global_entry_types','2024-07-02 17:29:03','2024-07-02 17:29:03','2024-07-02 17:29:03','dbc1ba4a-1907-4250-9972-27779fe328a5'),(14,'craft','m230531_123004_add_entry_type_show_status_field','2024-07-02 17:29:03','2024-07-02 17:29:03','2024-07-02 17:29:03','29af2070-de96-409a-b168-6cdefc65036f'),(15,'craft','m230607_102049_add_entrytype_slug_translation_columns','2024-07-02 17:29:03','2024-07-02 17:29:03','2024-07-02 17:29:03','bf5bf8d7-26a2-4819-8e1e-c48b99539e51'),(16,'craft','m230616_173810_kill_field_groups','2024-07-02 17:29:03','2024-07-02 17:29:03','2024-07-02 17:29:03','e58579e6-1833-41f8-b144-96b1314bafcf'),(17,'craft','m230616_183820_remove_field_name_limit','2024-07-02 17:29:03','2024-07-02 17:29:03','2024-07-02 17:29:03','4537e1de-7bae-4ba4-ac31-82e6f6ffb8a5'),(18,'craft','m230617_070415_entrify_matrix_blocks','2024-07-02 17:29:03','2024-07-02 17:29:03','2024-07-02 17:29:03','acd4e44d-3fbf-4ff5-aee4-734ab2b47e29'),(19,'craft','m230710_162700_element_activity','2024-07-02 17:29:03','2024-07-02 17:29:03','2024-07-02 17:29:03','720465cf-b515-43d8-8e8b-3019c368dd78'),(20,'craft','m230820_162023_fix_cache_id_type','2024-07-02 17:29:03','2024-07-02 17:29:03','2024-07-02 17:29:03','57c616ff-fbf8-450a-8cec-4cab2e53135e'),(21,'craft','m230826_094050_fix_session_id_type','2024-07-02 17:29:03','2024-07-02 17:29:03','2024-07-02 17:29:03','932e3497-ab78-41a5-afce-77eba8415ee0'),(22,'craft','m230904_190356_address_fields','2024-07-02 17:29:03','2024-07-02 17:29:03','2024-07-02 17:29:03','040e12de-21d9-4e2d-9b80-95d4c886bc3e'),(23,'craft','m230928_144045_add_subpath_to_volumes','2024-07-02 17:29:03','2024-07-02 17:29:03','2024-07-02 17:29:03','b3f82cf4-e4a5-4010-ad7c-18a8d345f9ac'),(24,'craft','m231013_185640_changedfields_amend_primary_key','2024-07-02 17:29:03','2024-07-02 17:29:03','2024-07-02 17:29:03','8487856c-779f-4db9-bc94-89d539f7c15c'),(25,'craft','m231213_030600_element_bulk_ops','2024-07-02 17:29:03','2024-07-02 17:29:03','2024-07-02 17:29:03','58289271-3367-4e9b-8a40-cf22d2d955b7'),(26,'craft','m240129_150719_sites_language_amend_length','2024-07-02 17:29:03','2024-07-02 17:29:03','2024-07-02 17:29:03','953cbcca-ac7d-45fc-b90c-8e2a37730cf2'),(27,'craft','m240206_035135_convert_json_columns','2024-07-02 17:29:03','2024-07-02 17:29:03','2024-07-02 17:29:03','b8787d38-8315-479d-ac79-68ac930af775'),(28,'craft','m240207_182452_address_line_3','2024-07-02 17:29:03','2024-07-02 17:29:03','2024-07-02 17:29:03','e27099e9-d513-46a6-ab71-2a7aa371b75a'),(29,'craft','m240302_212719_solo_preview_targets','2024-07-02 17:29:03','2024-07-02 17:29:03','2024-07-02 17:29:03','def97254-45cd-4506-bde8-2a086476426a'),(30,'craft','m240619_091352_add_auth_2fa_timestamp','2024-07-02 17:29:03','2024-07-02 17:29:03','2024-07-02 17:29:03','7945087c-2c13-4a7b-82e6-4c2f3772cb40'),(31,'plugin:commerce','Install','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','1ce34f51-e18d-4d22-be80-cf61707d75e5'),(32,'plugin:commerce','m210614_073359_detailed_permission','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','cf771ac6-bf17-40d0-901c-ebf88dbb427c'),(33,'plugin:commerce','m210831_080542_rename_variant_title_format_field','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','ad774931-e598-4ee7-bde9-6cb44c0f5779'),(34,'plugin:commerce','m210901_211323_not_null_booleans','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','f7b7ae4a-0ffe-4fcd-b516-ad60044fd707'),(35,'plugin:commerce','m210922_133729_add_discount_order_condition_builder','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','817fd334-63d8-463f-94dc-c3e3b5cd62cb'),(36,'plugin:commerce','m211118_101920_split_coupon_codes','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','048e1415-69cd-4554-a308-4f5bd27a2327'),(37,'plugin:commerce','m220301_022054_user_addresses','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','8f0d26eb-97ba-4dc0-ac50-7e840439cf49'),(38,'plugin:commerce','m220302_133730_add_discount_user_addresses_condition_builders','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','ee58792b-6323-4be9-bce9-2ddee98d9dc9'),(39,'plugin:commerce','m220304_094835_discount_conditions','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','956a057f-7bd1-4d32-9463-d1fce65ad334'),(40,'plugin:commerce','m220308_221717_orderhistory_name','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','8afa7f0b-7baf-4e93-a1c9-b1b6d5de118a'),(41,'plugin:commerce','m220329_075053_convert_gateway_frontend_enabled_column','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','d69f8bbd-ed95-4287-a2ed-2a631b6a367b'),(42,'plugin:commerce','m220706_132118_add_purchasable_tax_type','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','5ad0a452-eaa1-46a0-b393-35c66ff0eaba'),(43,'plugin:commerce','m220812_104819_add_primary_payment_source_column','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','3fe942f9-b331-4008-ab29-db1d08dc7ae2'),(44,'plugin:commerce','m220817_135050_add_purchase_total_back_if_missing','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','842e5307-3635-40d7-88c5-a48d53cebf13'),(45,'plugin:commerce','m220912_111800_add_order_total_qty_column','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','59a64ec1-fead-41d7-8045-c61583e3b320'),(46,'plugin:commerce','m221025_083940_add_purchasables_stores_table','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','4ef273b1-63c2-4197-8a22-036e6b420fc3'),(47,'plugin:commerce','m221026_105212_add_catalog_pricing_table','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','2ab2152d-584b-4c02-81a7-e9896e7338c1'),(48,'plugin:commerce','m221027_070322_add_tax_shipping_category_soft_delete','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','b500afcc-52ba-4288-883a-7e7b28ae102c'),(49,'plugin:commerce','m221027_074805_update_shipping_tax_category_indexes','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','9b762f4f-8fe2-4085-a9aa-fdc257c664ba'),(50,'plugin:commerce','m221028_192112_add_indexes_to_address_columns_on_orders','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','7e60541e-1380-4d05-92b6-47fb7dc90900'),(51,'plugin:commerce','m221122_055724_move_general_settings_to_per_store_settings','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','39ab55c2-d588-4d68-9745-2a9ae030e4b3'),(52,'plugin:commerce','m221122_055725_multi_store','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','8a4b36ec-190d-4ba7-a671-e2d3703779bf'),(53,'plugin:commerce','m221122_155735_update_orders_shippingMethodHandle_default','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','264aafd7-ca05-46aa-8634-ceef795c9a2b'),(54,'plugin:commerce','m221124_114239_add_date_deleted_to_stores','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','2559a7c9-6272-4615-be07-6e503d15947b'),(55,'plugin:commerce','m221206_094303_add_store_to_order','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','eddfd96c-afd0-4815-8f04-6c8889375601'),(56,'plugin:commerce','m221213_052623_drop_lite','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','154033a5-4a96-42cb-a4d8-0f4f74597a92'),(57,'plugin:commerce','m221213_070807_initial_storeId_records_transition','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','49a7ca4c-0c97-419f-af23-8ed911ec8509'),(58,'plugin:commerce','m230103_122549_add_product_type_max_variants','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','212daff1-2f4c-4179-becd-11835e9b53e2'),(59,'plugin:commerce','m230110_052712_site_stores','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','e3e51128-ccce-4d96-8e4f-d2e859c1cd0b'),(60,'plugin:commerce','m230111_112916_update_lineitems_table','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','1acf2327-a951-4d35-8a23-4901346de6b0'),(61,'plugin:commerce','m230113_110914_remove_soft_delete','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','019eab21-8f29-4f7f-9539-fb1ec2fa96c2'),(62,'plugin:commerce','m230118_114424_add_purchasables_stores_indexes','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','c0c3cce5-85ea-4b3d-909a-b0889e46c049'),(63,'plugin:commerce','m230126_105337_rename_discount_sales_references','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','0d7a4f04-dd2e-4674-8284-d207ed0cc212'),(64,'plugin:commerce','m230126_114655_add_catalog_pricing_rule_metadata_column','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','ef06280b-d1de-433a-9d60-5b16757184b3'),(65,'plugin:commerce','m230208_130445_add_store_id_to_shipping_categories','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','7caeb92e-cc75-411c-bda3-d6ee5f6e5338'),(66,'plugin:commerce','m230210_093749_add_store_id_to_shipping_methods','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','631c7e05-d0d1-4acd-ae95-c0b334cf90d0'),(67,'plugin:commerce','m230210_141514_add_store_id_to_shipping_zones','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','496dbd8b-6470-4507-ae2c-f29176362b17'),(68,'plugin:commerce','m230214_094122_add_total_weight_column_to_orders','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','ccaab544-d013-4e09-878b-5048acfbdb48'),(69,'plugin:commerce','m230214_095055_update_name_index_on_shipping_zones','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','399857c5-3bd2-4ed0-8d3e-cf17b5179f3b'),(70,'plugin:commerce','m230215_083820_add_order_condition_to_shipping_rules','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','1f817b87-928e-4b2a-8679-80bacf9a008e'),(71,'plugin:commerce','m230215_114552_migrate_shipping_rule_conditions_to_condition_builder','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','5ba2e012-3778-4c63-979f-01b6c2ceec84'),(72,'plugin:commerce','m230217_095845_remove_shipping_rules_columns','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','6cf345fa-3764-49bb-9795-3c0acf7533b8'),(73,'plugin:commerce','m230217_143255_add_shipping_method_order_condition','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','ac826ccd-5b3c-47c6-bfde-dc7f958e299c'),(74,'plugin:commerce','m230220_075106_add_store_id_to_tax_rates','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','7d323392-082e-4923-a93a-d9d612bd0949'),(75,'plugin:commerce','m230220_080107_add_store_id_to_tax_zones','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','83c92181-780a-4fcf-ab4b-c892b4c4b922'),(76,'plugin:commerce','m230307_091520_add_sort_order_to_stores','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','8247dff9-e0fa-440f-aa21-ecdbc3ac3337'),(77,'plugin:commerce','m230308_084340_add_store_id_to_order_statuses','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','e506b7af-f036-4dcf-8506-6b4602bf7a35'),(78,'plugin:commerce','m230310_102639_add_store_id_to_line_item_statuses','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','f1798f80-c5bd-4908-bc5d-07ab1f1d4060'),(79,'plugin:commerce','m230313_095359_add_store_id_to_emails','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','42cea115-e3ca-4d1f-9f64-017023f1136e'),(80,'plugin:commerce','m230317_102521_add_store_id_to_pdfs','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','c1a67478-32aa-47f1-81e1-128d594dc8b9'),(81,'plugin:commerce','m230322_091615_move_email_settings_to_model','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','a7c34b6a-b291-480a-a2c8-ccc9597ad21a'),(82,'plugin:commerce','m230328_130343_move_pdf_settings_to_model','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','f7c14a47-c82c-404a-960e-c1fd15afe43b'),(83,'plugin:commerce','m230525_081243_add_has_update_pending_property','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','fa0956da-a2d0-4d64-8c5d-a0c1c05581e7'),(84,'plugin:commerce','m230530_100604_add_complete_email_column','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','4e13c854-91bb-4a7d-be40-1c3ac132eb00'),(85,'plugin:commerce','m230705_124845_add_save_address_columns','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','e83c0a0c-49e2-44f9-829e-8ee44c73a5f1'),(86,'plugin:commerce','m230719_082348_discount_nullable_conditions','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','faed1483-e762-4fab-a9b1-0ef7ff38cb30'),(87,'plugin:commerce','m230724_080855_entrify_promotions','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','c5f3bb9a-7b06-46df-9e56-08333003fca1'),(88,'plugin:commerce','m230920_051125_move_primary_currency_to_store_settings','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','b978a818-13d5-46a9-8c4c-a68a1ffd16cf'),(89,'plugin:commerce','m230928_095544_fix_unique_on_some_tables','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','4faea2cc-5a05-47cf-a371-1e0e06f65729'),(90,'plugin:commerce','m230928_155052_move_shipping_category_id_to_purchasable_stores','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','46f2ef3d-5fba-4b1f-bf72-c958c43dac8e'),(91,'plugin:commerce','m231006_034833_add_indexes_for_source_address_on_order','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','7efe3aca-cd32-4127-8765-4987684c0512'),(92,'plugin:commerce','m231019_110814_update_variant_ownership','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','831d26e3-9903-4c14-8be4-1ce1a4caa7f4'),(93,'plugin:commerce','m231110_081143_inventory_movement_table','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','d46c5371-54a3-4356-bb43-701c4630692d'),(94,'plugin:commerce','m231201_100454_update_discount_base_discount_type','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','28206d0d-83f3-4e9a-bbe6-e90442fb2cb7'),(95,'plugin:commerce','m240119_073924_content_refactor_elements','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','1d5922cc-d208-48cd-b3e7-9df480391a9a'),(96,'plugin:commerce','m240119_075036_content_refactor_subscription_elements','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','e00260ef-0d4d-46a0-be86-e406a3b90ce4'),(97,'plugin:commerce','m240208_083054_add_purchasable_stores_purchasable_fk','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','db06ff04-bf82-4fbd-a2a7-e81b8866b395'),(98,'plugin:commerce','m240219_194855_donation_multi_store','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','3ecbfd3e-b4b4-4e6c-adc7-a66bad9f3bdd'),(99,'plugin:commerce','m240220_045806_product_versioning','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','f1a8d1e2-d136-49af-8023-4729be840537'),(100,'plugin:commerce','m240220_105746_remove_store_from_donations_table','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','25dc1cb8-2e83-48d0-968e-ebac6cdc98ff'),(101,'plugin:commerce','m240221_030027_transfer_items','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','34ae26b4-3349-467d-827b-fd83bddffc41'),(102,'plugin:commerce','m240223_101158_update_recent_orders_widget_settings','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','c8675f29-0810-4351-8e26-b1ee51e056d6'),(103,'plugin:commerce','m240226_002943_remove_lite','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','16daa1b5-3798-457d-a76d-71950ac8a8c9'),(104,'plugin:commerce','m240228_054005_rename_movements_table','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','84856ec4-c73c-4fee-9b36-0d7840aa2b9e'),(105,'plugin:commerce','m240228_060604_add_fufilled_type_to_inventorytransactions','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','b025e35b-bd11-4a4d-8bc1-0e6db453e4f4'),(106,'plugin:commerce','m240228_120911_drop_order_id_and_make_line_item_cascade','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','0ef2f084-2217-4092-978a-3c8f0e84a19e'),(107,'plugin:commerce','m240306_091057_move_element_ids_on_discount_to_columns','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','2895dda7-0743-4673-b196-873eb6414ee7'),(108,'plugin:commerce','m240308_133451_tidy_shipping_categories','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','20ea446b-ac8c-4756-9d8a-c4ab346bc404'),(109,'plugin:commerce','m240313_131445_tidy_shipping_methods','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','a09ff4f7-7101-412f-a021-476e8733ba6b'),(110,'plugin:commerce','m240315_072659_add_fk_cascade_fixes','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','39fcffb5-9b65-4e02-92e8-e17d328c9711'),(111,'plugin:commerce','m240430_161804_add_index_to_transaction_hash','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','2edfaf5b-2c5a-4c4c-b3de-e2ce6a805991'),(112,'plugin:commerce','m240507_081904_fix_store_pc_location','2024-07-02 17:30:54','2024-07-02 17:30:54','2024-07-02 17:30:54','d56638bb-ebe5-49f8-a42d-ca4e45acedbb');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plugins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_hewygxqyzabfdullqiovhntshadwcalmqtlu` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
INSERT INTO `plugins` VALUES (1,'commerce','5.0.11.1','5.0.74','2024-07-02 17:30:38','2024-07-02 17:30:38','2024-07-02 17:30:38','749ac210-cb50-4df0-a420-630f9616ff04'),(2,'timber','2.0.1','1.0.0','2024-07-02 17:53:05','2024-07-02 17:53:05','2024-07-02 17:53:05','965004d3-b603-4b0d-ad1c-5104e64c8844');
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projectconfig`
--

DROP TABLE IF EXISTS `projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projectconfig` (
  `path` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectconfig`
--

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;
INSERT INTO `projectconfig` VALUES ('commerce.gateways.22ed0f81-7934-43be-9e7e-8cfe3587c410.handle','\"dummy\"'),('commerce.gateways.22ed0f81-7934-43be-9e7e-8cfe3587c410.isFrontendEnabled','true'),('commerce.gateways.22ed0f81-7934-43be-9e7e-8cfe3587c410.name','\"Dummy\"'),('commerce.gateways.22ed0f81-7934-43be-9e7e-8cfe3587c410.paymentType','\"purchase\"'),('commerce.gateways.22ed0f81-7934-43be-9e7e-8cfe3587c410.sortOrder','99'),('commerce.gateways.22ed0f81-7934-43be-9e7e-8cfe3587c410.type','\"craft\\\\commerce\\\\gateways\\\\Dummy\"'),('commerce.orderStatuses.e2e770f1-9ee6-4664-a29c-482aa27e753a.color','\"green\"'),('commerce.orderStatuses.e2e770f1-9ee6-4664-a29c-482aa27e753a.default','true'),('commerce.orderStatuses.e2e770f1-9ee6-4664-a29c-482aa27e753a.description','null'),('commerce.orderStatuses.e2e770f1-9ee6-4664-a29c-482aa27e753a.handle','\"new\"'),('commerce.orderStatuses.e2e770f1-9ee6-4664-a29c-482aa27e753a.name','\"New\"'),('commerce.orderStatuses.e2e770f1-9ee6-4664-a29c-482aa27e753a.sortOrder','99'),('commerce.orderStatuses.e2e770f1-9ee6-4664-a29c-482aa27e753a.store','\"ac75e754-1dde-4b93-aeb9-e267f370616b\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.descriptionFormat','\"{product.title} - {title}\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.enableVersioning','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.handle','\"general\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.hasDimensions','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.hasProductTitleField','true'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.hasVariantTitleField','true'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.maxVariants','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.name','\"General\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elementCondition','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.0.autocapitalize','true'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.0.autocomplete','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.0.autocorrect','true'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.0.class','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.0.disabled','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.0.elementCondition','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.0.id','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.0.includeInCards','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.0.inputType','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.0.instructions','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.0.label','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.0.max','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.0.min','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.0.name','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.0.orientation','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.0.placeholder','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.0.providesThumbs','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.0.readonly','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.0.requirable','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.0.size','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.0.step','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.0.tip','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.0.title','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.0.type','\"craft\\\\commerce\\\\fieldlayoutelements\\\\ProductTitleField\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.0.uid','\"aae4208f-eba9-481b-b63e-a40000beed42\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.0.userCondition','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.0.warning','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.0.width','100'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.1.attribute','\"variants\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.1.elementCondition','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.1.id','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.1.includeInCards','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.1.instructions','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.1.label','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.1.mandatory','true'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.1.orientation','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.1.providesThumbs','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.1.requirable','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.1.required','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.1.tip','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.1.translatable','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.1.type','\"craft\\\\commerce\\\\fieldlayoutelements\\\\VariantsField\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.1.uid','\"7f70031b-f473-41ac-b37c-f08c1333fa90\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.1.userCondition','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.1.warning','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.2.elementCondition','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.2.fieldUid','\"c8c46842-af9f-4880-aebc-26583c15b659\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.2.handle','\"customRequiredField1\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.2.includeInCards','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.2.instructions','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.2.label','\"Custom Required Field 1\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.2.providesThumbs','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.2.required','true'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.2.tip','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.2.uid','\"6e43c6c9-f5a4-42a8-a1de-161847fc7b69\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.2.userCondition','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.2.warning','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.2.width','100'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.3.elementCondition','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.3.fieldUid','\"376223de-9e80-4a0d-84ea-8877242918e1\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.3.handle','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.3.includeInCards','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.3.instructions','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.3.label','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.3.providesThumbs','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.3.required','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.3.tip','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.3.uid','\"80507a11-a09b-43c2-9a5c-35ebea97a44a\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.3.userCondition','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.3.warning','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.elements.3.width','100'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.name','\"Content\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.uid','\"5ff418e5-3c49-4075-81e9-f5aa31f9d7bd\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productFieldLayouts.446e6dcb-4af8-4959-b422-616cdd4338b7.tabs.0.userCondition','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.productTitleFormat','\"\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.siteSettings.6fc0244d-6ccb-4cb1-b1e5-c10752c00220.hasUrls','true'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.siteSettings.6fc0244d-6ccb-4cb1-b1e5-c10752c00220.template','\"\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.siteSettings.6fc0244d-6ccb-4cb1-b1e5-c10752c00220.uriFormat','\"general/{slug}\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.skuFormat','\"\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elementCondition','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.0.autocapitalize','true'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.0.autocomplete','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.0.autocorrect','true'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.0.class','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.0.disabled','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.0.elementCondition','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.0.id','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.0.includeInCards','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.0.inputType','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.0.instructions','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.0.label','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.0.max','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.0.min','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.0.name','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.0.orientation','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.0.placeholder','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.0.providesThumbs','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.0.readonly','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.0.requirable','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.0.size','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.0.step','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.0.tip','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.0.title','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.0.type','\"craft\\\\commerce\\\\fieldlayoutelements\\\\VariantTitleField\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.0.uid','\"d10c9eb9-bfb0-4d40-9134-79580b30c67b\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.0.userCondition','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.0.warning','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.0.width','100'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.1.attribute','\"sku\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.1.elementCondition','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.1.id','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.1.includeInCards','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.1.instructions','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.1.label','\"SKU\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.1.mandatory','true'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.1.orientation','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.1.providesThumbs','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.1.requirable','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.1.required','true'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.1.tip','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.1.translatable','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.1.type','\"craft\\\\commerce\\\\fieldlayoutelements\\\\PurchasableSkuField\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.1.uid','\"eb0d228f-dc71-44ab-a790-66177d47acb4\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.1.userCondition','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.1.warning','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.1.width','100'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.2.attribute','\"price\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.2.elementCondition','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.2.id','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.2.includeInCards','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.2.instructions','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.2.label','\"__blank__\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.2.mandatory','true'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.2.orientation','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.2.providesThumbs','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.2.requirable','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.2.required','true'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.2.tip','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.2.translatable','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.2.type','\"craft\\\\commerce\\\\fieldlayoutelements\\\\PurchasablePriceField\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.2.uid','\"66707687-4295-45a1-bc8e-a8568651ffd5\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.2.userCondition','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.2.warning','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.2.width','100'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.3.attribute','\"stock\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.3.elementCondition','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.3.id','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.3.includeInCards','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.3.instructions','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.3.label','\"Inventory\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.3.mandatory','true'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.3.orientation','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.3.providesThumbs','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.3.requirable','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.3.required','true'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.3.tip','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.3.translatable','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.3.type','\"craft\\\\commerce\\\\fieldlayoutelements\\\\PurchasableStockField\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.3.uid','\"cc719aab-77be-4243-be19-d6a116800298\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.3.userCondition','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.3.warning','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.3.width','100'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.4.attribute','\"availableForPurchase\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.4.elementCondition','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.4.id','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.4.includeInCards','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.4.instructions','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.4.label','\"Available for purchase\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.4.mandatory','true'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.4.orientation','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.4.providesThumbs','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.4.requirable','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.4.required','true'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.4.tip','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.4.translatable','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.4.type','\"craft\\\\commerce\\\\fieldlayoutelements\\\\PurchasableAvailableForPurchaseField\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.4.uid','\"9dce4367-4cb3-4a11-b0a7-8d8484ea0d6a\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.4.userCondition','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.4.warning','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.4.width','100'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.5.attribute','\"allowedQty\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.5.elementCondition','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.5.id','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.5.includeInCards','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.5.instructions','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.5.label','\"Allowed Qty\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.5.mandatory','true'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.5.orientation','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.5.providesThumbs','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.5.requirable','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.5.required','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.5.tip','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.5.translatable','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.5.type','\"craft\\\\commerce\\\\fieldlayoutelements\\\\PurchasableAllowedQtyField\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.5.uid','\"812a5893-9d93-4d42-8476-f565ddb10526\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.5.userCondition','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.5.warning','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.5.width','100'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.6.attribute','\"freeShipping\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.6.elementCondition','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.6.id','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.6.includeInCards','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.6.instructions','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.6.label','\"Free Shipping\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.6.mandatory','true'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.6.orientation','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.6.providesThumbs','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.6.requirable','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.6.required','true'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.6.tip','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.6.translatable','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.6.type','\"craft\\\\commerce\\\\fieldlayoutelements\\\\PurchasableFreeShippingField\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.6.uid','\"13cb3f56-a613-4cdf-8afd-76392d095d1d\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.6.userCondition','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.6.warning','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.6.width','100'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.7.attribute','\"promotable\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.7.elementCondition','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.7.id','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.7.includeInCards','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.7.instructions','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.7.label','\"Promotable\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.7.mandatory','true'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.7.orientation','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.7.providesThumbs','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.7.requirable','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.7.required','true'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.7.tip','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.7.translatable','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.7.type','\"craft\\\\commerce\\\\fieldlayoutelements\\\\PurchasablePromotableField\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.7.uid','\"914b039e-12be-4c21-8822-0e9c581e9dc5\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.7.userCondition','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.7.warning','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.7.width','100'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.8.attribute','\"dimensions\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.8.elementCondition','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.8.id','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.8.includeInCards','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.8.instructions','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.8.label','\"Dimensions\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.8.mandatory','true'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.8.orientation','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.8.providesThumbs','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.8.requirable','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.8.required','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.8.tip','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.8.translatable','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.8.type','\"craft\\\\commerce\\\\fieldlayoutelements\\\\PurchasableDimensionsField\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.8.uid','\"6c5b8306-6435-44bb-b04d-4921b089dc30\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.8.userCondition','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.8.warning','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.8.width','100'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.9.attribute','\"weight\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.9.elementCondition','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.9.id','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.9.includeInCards','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.9.instructions','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.9.label','\"Weight\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.9.mandatory','true'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.9.orientation','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.9.providesThumbs','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.9.requirable','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.9.required','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.9.tip','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.9.translatable','false'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.9.type','\"craft\\\\commerce\\\\fieldlayoutelements\\\\PurchasableWeightField\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.9.uid','\"4f8453e9-e685-46e8-aa55-d21fea612d1e\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.9.userCondition','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.9.warning','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.elements.9.width','100'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.name','\"Content\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.uid','\"cdf25b1e-c3d5-498a-abfb-6788704e9ca5\"'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantFieldLayouts.993b0a3a-38ca-4d3f-b382-72807d3fb558.tabs.0.userCondition','null'),('commerce.productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83.variantTitleFormat','\"{product.title}\"'),('commerce.sitestores.6fc0244d-6ccb-4cb1-b1e5-c10752c00220.store','\"ac75e754-1dde-4b93-aeb9-e267f370616b\"'),('commerce.stores.ac75e754-1dde-4b93-aeb9-e267f370616b.allowCheckoutWithoutPayment','\"0\"'),('commerce.stores.ac75e754-1dde-4b93-aeb9-e267f370616b.allowEmptyCartOnCheckout','\"0\"'),('commerce.stores.ac75e754-1dde-4b93-aeb9-e267f370616b.allowPartialPaymentOnCheckout','\"0\"'),('commerce.stores.ac75e754-1dde-4b93-aeb9-e267f370616b.autoSetCartShippingMethodOption','\"0\"'),('commerce.stores.ac75e754-1dde-4b93-aeb9-e267f370616b.autoSetNewCartAddresses','\"0\"'),('commerce.stores.ac75e754-1dde-4b93-aeb9-e267f370616b.autoSetPaymentSource','\"0\"'),('commerce.stores.ac75e754-1dde-4b93-aeb9-e267f370616b.currency','\"EUR\"'),('commerce.stores.ac75e754-1dde-4b93-aeb9-e267f370616b.freeOrderPaymentStrategy','\"complete\"'),('commerce.stores.ac75e754-1dde-4b93-aeb9-e267f370616b.handle','\"primary\"'),('commerce.stores.ac75e754-1dde-4b93-aeb9-e267f370616b.minimumTotalPriceStrategy','\"default\"'),('commerce.stores.ac75e754-1dde-4b93-aeb9-e267f370616b.name','\"Primary\"'),('commerce.stores.ac75e754-1dde-4b93-aeb9-e267f370616b.orderReferenceFormat','\"{{number[:7]}}\"'),('commerce.stores.ac75e754-1dde-4b93-aeb9-e267f370616b.primary','true'),('commerce.stores.ac75e754-1dde-4b93-aeb9-e267f370616b.requireBillingAddressAtCheckout','\"0\"'),('commerce.stores.ac75e754-1dde-4b93-aeb9-e267f370616b.requireShippingAddressAtCheckout','\"0\"'),('commerce.stores.ac75e754-1dde-4b93-aeb9-e267f370616b.requireShippingMethodSelectionAtCheckout','\"0\"'),('commerce.stores.ac75e754-1dde-4b93-aeb9-e267f370616b.sortOrder','99'),('commerce.stores.ac75e754-1dde-4b93-aeb9-e267f370616b.useBillingAddressForTax','\"0\"'),('commerce.stores.ac75e754-1dde-4b93-aeb9-e267f370616b.validateOrganizationTaxIdAsVatId','\"0\"'),('dateModified','1721382128'),('email.fromEmail','\"admin@example.com\"'),('email.fromName','\"Testsite\"'),('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.color','null'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.elementCondition','null'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.elements.0.autocapitalize','true'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.elements.0.autocomplete','false'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.elements.0.autocorrect','true'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.elements.0.class','null'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.elements.0.disabled','false'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.elements.0.elementCondition','null'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.elements.0.id','null'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.elements.0.includeInCards','false'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.elements.0.inputType','null'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.elements.0.instructions','null'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.elements.0.label','null'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.elements.0.max','null'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.elements.0.min','null'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.elements.0.name','null'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.elements.0.orientation','null'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.elements.0.placeholder','null'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.elements.0.providesThumbs','false'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.elements.0.readonly','false'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.elements.0.requirable','false'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.elements.0.size','null'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.elements.0.step','null'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.elements.0.tip','null'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.elements.0.title','null'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.elements.0.uid','\"7ca94726-5e2a-4cdc-8918-497541e7a5f8\"'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.elements.0.userCondition','null'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.elements.0.warning','null'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.elements.0.width','100'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.elements.1.elementCondition','null'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.elements.1.fieldUid','\"c8c46842-af9f-4880-aebc-26583c15b659\"'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.elements.1.handle','\"subline\"'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.elements.1.includeInCards','false'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.elements.1.instructions','null'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.elements.1.label','\"Subline\"'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.elements.1.providesThumbs','false'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.elements.1.required','false'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.elements.1.tip','null'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.elements.1.uid','\"d1e71e52-bd18-4e2c-85b0-96e7d888de5b\"'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.elements.1.userCondition','null'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.elements.1.warning','null'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.elements.1.width','100'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.name','\"Content\"'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.uid','\"78cd103a-cd04-48a9-983e-fbc7fc72241b\"'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.fieldLayouts.9c9ebbe4-6a5d-4400-a887-adf6c96acedc.tabs.0.userCondition','null'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.handle','\"productCategory\"'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.hasTitleField','true'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.icon','\"\"'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.name','\"Product Category\"'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.showSlugField','false'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.showStatusField','false'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.slugTranslationKeyFormat','null'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.slugTranslationMethod','\"site\"'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.titleFormat','\"\"'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.titleTranslationKeyFormat','null'),('entryTypes.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd.titleTranslationMethod','\"site\"'),('fields.376223de-9e80-4a0d-84ea-8877242918e1.columnSuffix','null'),('fields.376223de-9e80-4a0d-84ea-8877242918e1.handle','\"productCategories\"'),('fields.376223de-9e80-4a0d-84ea-8877242918e1.instructions','\"Select one product category, multiple categories are not supported here.\\r\\n\\r\\n\"'),('fields.376223de-9e80-4a0d-84ea-8877242918e1.name','\"Product Categories\"'),('fields.376223de-9e80-4a0d-84ea-8877242918e1.searchable','false'),('fields.376223de-9e80-4a0d-84ea-8877242918e1.settings.allowSelfRelations','false'),('fields.376223de-9e80-4a0d-84ea-8877242918e1.settings.branchLimit','1'),('fields.376223de-9e80-4a0d-84ea-8877242918e1.settings.localizeRelations','false'),('fields.376223de-9e80-4a0d-84ea-8877242918e1.settings.maintainHierarchy','true'),('fields.376223de-9e80-4a0d-84ea-8877242918e1.settings.maxRelations','null'),('fields.376223de-9e80-4a0d-84ea-8877242918e1.settings.minRelations','null'),('fields.376223de-9e80-4a0d-84ea-8877242918e1.settings.selectionLabel','null'),('fields.376223de-9e80-4a0d-84ea-8877242918e1.settings.showCardsInGrid','false'),('fields.376223de-9e80-4a0d-84ea-8877242918e1.settings.showSiteMenu','false'),('fields.376223de-9e80-4a0d-84ea-8877242918e1.settings.sources.0','\"section:cdec25d5-684f-41ff-8fc7-f0935d020549\"'),('fields.376223de-9e80-4a0d-84ea-8877242918e1.settings.targetSiteId','null'),('fields.376223de-9e80-4a0d-84ea-8877242918e1.settings.validateRelatedElements','false'),('fields.376223de-9e80-4a0d-84ea-8877242918e1.settings.viewMode','\"list\"'),('fields.376223de-9e80-4a0d-84ea-8877242918e1.translationKeyFormat','null'),('fields.376223de-9e80-4a0d-84ea-8877242918e1.translationMethod','\"site\"'),('fields.376223de-9e80-4a0d-84ea-8877242918e1.type','\"craft\\\\fields\\\\Entries\"'),('fields.c8c46842-af9f-4880-aebc-26583c15b659.columnSuffix','null'),('fields.c8c46842-af9f-4880-aebc-26583c15b659.handle','\"commonPlainText\"'),('fields.c8c46842-af9f-4880-aebc-26583c15b659.instructions','null'),('fields.c8c46842-af9f-4880-aebc-26583c15b659.name','\"Common Plain Text\"'),('fields.c8c46842-af9f-4880-aebc-26583c15b659.searchable','false'),('fields.c8c46842-af9f-4880-aebc-26583c15b659.settings.byteLimit','null'),('fields.c8c46842-af9f-4880-aebc-26583c15b659.settings.charLimit','null'),('fields.c8c46842-af9f-4880-aebc-26583c15b659.settings.code','false'),('fields.c8c46842-af9f-4880-aebc-26583c15b659.settings.initialRows','4'),('fields.c8c46842-af9f-4880-aebc-26583c15b659.settings.multiline','false'),('fields.c8c46842-af9f-4880-aebc-26583c15b659.settings.placeholder','null'),('fields.c8c46842-af9f-4880-aebc-26583c15b659.settings.uiMode','\"normal\"'),('fields.c8c46842-af9f-4880-aebc-26583c15b659.translationKeyFormat','null'),('fields.c8c46842-af9f-4880-aebc-26583c15b659.translationMethod','\"none\"'),('fields.c8c46842-af9f-4880-aebc-26583c15b659.type','\"craft\\\\fields\\\\PlainText\"'),('graphql.schemas.0f99cee4-5957-4b55-8de9-9b03ebe0f9f8.isPublic','true'),('graphql.schemas.0f99cee4-5957-4b55-8de9-9b03ebe0f9f8.name','\"Public Schema\"'),('graphql.schemas.9ef8f2a9-d981-4a73-8db1-69675b452cea.isPublic','false'),('graphql.schemas.9ef8f2a9-d981-4a73-8db1-69675b452cea.name','\"Private Schema\"'),('graphql.schemas.9ef8f2a9-d981-4a73-8db1-69675b452cea.scope.0','\"sites.6fc0244d-6ccb-4cb1-b1e5-c10752c00220:read\"'),('graphql.schemas.9ef8f2a9-d981-4a73-8db1-69675b452cea.scope.1','\"sections.cdec25d5-684f-41ff-8fc7-f0935d020549:read\"'),('graphql.schemas.9ef8f2a9-d981-4a73-8db1-69675b452cea.scope.2','\"usergroups.everyone:read\"'),('graphql.schemas.9ef8f2a9-d981-4a73-8db1-69675b452cea.scope.3','\"productTypes.660b2918-0d3b-4556-ae6f-0e4f8adc5e83:read\"'),('graphql.schemas.9ef8f2a9-d981-4a73-8db1-69675b452cea.scope.4','\"sections.cdec25d5-684f-41ff-8fc7-f0935d020549:edit\"'),('graphql.schemas.9ef8f2a9-d981-4a73-8db1-69675b452cea.scope.5','\"sections.cdec25d5-684f-41ff-8fc7-f0935d020549:create\"'),('graphql.schemas.9ef8f2a9-d981-4a73-8db1-69675b452cea.scope.6','\"sections.cdec25d5-684f-41ff-8fc7-f0935d020549:save\"'),('graphql.schemas.9ef8f2a9-d981-4a73-8db1-69675b452cea.scope.7','\"sections.cdec25d5-684f-41ff-8fc7-f0935d020549:delete\"'),('meta.__names__.0f99cee4-5957-4b55-8de9-9b03ebe0f9f8','\"Public Schema\"'),('meta.__names__.22ed0f81-7934-43be-9e7e-8cfe3587c410','\"Dummy\"'),('meta.__names__.376223de-9e80-4a0d-84ea-8877242918e1','\"Product Categories\"'),('meta.__names__.48339d33-cdce-440a-95f7-107756106329','\"Testsite\"'),('meta.__names__.660b2918-0d3b-4556-ae6f-0e4f8adc5e83','\"General\"'),('meta.__names__.6fc0244d-6ccb-4cb1-b1e5-c10752c00220','\"Testsite\"'),('meta.__names__.96c3a328-d0ec-483b-82b3-5e9cbf59a3cd','\"Product Category\"'),('meta.__names__.9ef8f2a9-d981-4a73-8db1-69675b452cea','\"Private Schema\"'),('meta.__names__.ac75e754-1dde-4b93-aeb9-e267f370616b','\"Primary\"'),('meta.__names__.c8c46842-af9f-4880-aebc-26583c15b659','\"Common Plain Text\"'),('meta.__names__.cdec25d5-684f-41ff-8fc7-f0935d020549','\"Product Categories\"'),('meta.__names__.e2e770f1-9ee6-4664-a29c-482aa27e753a','\"New\"'),('plugins.commerce.edition','\"pro\"'),('plugins.commerce.enabled','true'),('plugins.commerce.licenseKey','\"5NUHDPZQV5E5A23BGY97RT7X\"'),('plugins.commerce.schemaVersion','\"5.0.74\"'),('plugins.timber.edition','\"standard\"'),('plugins.timber.enabled','true'),('plugins.timber.licenseKey','\"YPU0AZ4OKM5T0E4JQRKVLKXO\"'),('plugins.timber.schemaVersion','\"1.0.0\"'),('sections.cdec25d5-684f-41ff-8fc7-f0935d020549.defaultPlacement','\"end\"'),('sections.cdec25d5-684f-41ff-8fc7-f0935d020549.enableVersioning','false'),('sections.cdec25d5-684f-41ff-8fc7-f0935d020549.entryTypes.0','\"96c3a328-d0ec-483b-82b3-5e9cbf59a3cd\"'),('sections.cdec25d5-684f-41ff-8fc7-f0935d020549.handle','\"productCategories\"'),('sections.cdec25d5-684f-41ff-8fc7-f0935d020549.maxAuthors','1'),('sections.cdec25d5-684f-41ff-8fc7-f0935d020549.name','\"Product Categories\"'),('sections.cdec25d5-684f-41ff-8fc7-f0935d020549.propagationMethod','\"all\"'),('sections.cdec25d5-684f-41ff-8fc7-f0935d020549.siteSettings.6fc0244d-6ccb-4cb1-b1e5-c10752c00220.enabledByDefault','true'),('sections.cdec25d5-684f-41ff-8fc7-f0935d020549.siteSettings.6fc0244d-6ccb-4cb1-b1e5-c10752c00220.hasUrls','true'),('sections.cdec25d5-684f-41ff-8fc7-f0935d020549.siteSettings.6fc0244d-6ccb-4cb1-b1e5-c10752c00220.template','\"product-categories/_entry\"'),('sections.cdec25d5-684f-41ff-8fc7-f0935d020549.siteSettings.6fc0244d-6ccb-4cb1-b1e5-c10752c00220.uriFormat','\"product-categories/{slug}\"'),('sections.cdec25d5-684f-41ff-8fc7-f0935d020549.structure.maxLevels','1'),('sections.cdec25d5-684f-41ff-8fc7-f0935d020549.structure.uid','\"e392f163-05ee-442b-a235-cc4cc1554964\"'),('sections.cdec25d5-684f-41ff-8fc7-f0935d020549.type','\"structure\"'),('siteGroups.48339d33-cdce-440a-95f7-107756106329.name','\"Testsite\"'),('sites.6fc0244d-6ccb-4cb1-b1e5-c10752c00220.baseUrl','\"$DDEV_PRIMARY_URL\"'),('sites.6fc0244d-6ccb-4cb1-b1e5-c10752c00220.handle','\"default\"'),('sites.6fc0244d-6ccb-4cb1-b1e5-c10752c00220.hasUrls','true'),('sites.6fc0244d-6ccb-4cb1-b1e5-c10752c00220.language','\"en\"'),('sites.6fc0244d-6ccb-4cb1-b1e5-c10752c00220.name','\"Testsite\"'),('sites.6fc0244d-6ccb-4cb1-b1e5-c10752c00220.primary','true'),('sites.6fc0244d-6ccb-4cb1-b1e5-c10752c00220.siteGroup','\"48339d33-cdce-440a-95f7-107756106329\"'),('sites.6fc0244d-6ccb-4cb1-b1e5-c10752c00220.sortOrder','1'),('system.edition','\"pro\"'),('system.live','true'),('system.name','\"Testsite\"'),('system.schemaVersion','\"5.0.0.21\"'),('system.timeZone','\"America/Los_Angeles\"'),('users.allowPublicRegistration','false'),('users.defaultGroup','null'),('users.photoSubpath','null'),('users.photoVolumeUid','null'),('users.require2fa','false'),('users.requireEmailVerification','true');
/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `queue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text,
  `timePushed` int NOT NULL,
  `ttr` int NOT NULL,
  `delay` int NOT NULL DEFAULT '0',
  `priority` int unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int DEFAULT NULL,
  `progress` smallint NOT NULL DEFAULT '0',
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `idx_xvydavkhmehxrlrpxlkriceeyvhymniqnmfw` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `idx_mipriaosyvftkzdvbeypdwykeaycccfjeoin` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recoverycodes`
--

DROP TABLE IF EXISTS `recoverycodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recoverycodes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `recoveryCodes` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recoverycodes`
--

LOCK TABLES `recoverycodes` WRITE;
/*!40000 ALTER TABLE `recoverycodes` DISABLE KEYS */;
/*!40000 ALTER TABLE `recoverycodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `relations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `sourceId` int NOT NULL,
  `sourceSiteId` int DEFAULT NULL,
  `targetId` int NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_usaavzvadwwirvyjtmhvfxzakgqdlscseprv` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_zopilugrxxheghubzkdpdrlwqibfgucxducn` (`sourceId`),
  KEY `idx_iusubjiyxeidxhistfhigdqhbknwigsmxwnq` (`targetId`),
  KEY `idx_xhuoijusoeykkxlquzwveddjxstkupildqbb` (`sourceSiteId`),
  CONSTRAINT `fk_nyarnfokrmbgmvhichdemfyfiktakpmrphoz` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pwozpviqokaccmevxlonmumtsdmqcvlkgjwq` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ywncevdhgfvzhyvhrvclfafhualttynvwlrb` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resourcepaths`
--

LOCK TABLES `resourcepaths` WRITE;
/*!40000 ALTER TABLE `resourcepaths` DISABLE KEYS */;
INSERT INTO `resourcepaths` VALUES ('18036a86','@craft/web/assets/htmx/dist'),('234d7842','@craft/web/assets/jqueryui/dist'),('29aae854','@bower/jquery/dist'),('2c4af7bc','@craft/web/assets/elementresizedetector/dist'),('36be8d80','@craft/web/assets/prismjs/dist'),('3d36aee9','@craft/web/assets/fileupload/dist'),('416bb450','@craft/commerce/web/assets/productindex/dist'),('435f9942','@craft/web/assets/picturefill/dist'),('48e72442','@craft/web/assets/xregexp/dist'),('4a83f386','@craft/web/assets/craftsupport/dist'),('4c2d69fe','@craft/web/assets/timepicker/dist'),('6832353d','@craft/web/assets/plugins/dist'),('6eb39970','@craft/web/assets/vue/dist'),('6ed438cf','@craft/commerce/web/assets/inventory/dist'),('6eeb692f','@craft/web/assets/editsection/dist'),('710fca5b','@craft/web/assets/datepickeri18n/dist'),('7596cec2','@craft/web/assets/feed/dist'),('7a93412b','@craft/web/assets/velocity/dist'),('7f04439c','@craft/web/assets/jquerypayment/dist'),('7f579cfe','@craft/web/assets/jquerytouchevents/dist'),('82558b64','@craft/web/assets/money/dist'),('84b50602','@craft/web/assets/admintable/dist'),('8db8dfb1','@craft/web/assets/graphiql/dist'),('953b45fd','@craft/web/assets/garnish/dist'),('a9a89ea2','@craft/commerce/web/assets/commercecp/dist'),('ada3e4d4','@craft/web/assets/utilities/dist'),('afcc329e','@craft/web/assets/userpermissions/dist'),('b8aa2ef7','@craft/commerce/web/assets/orderswidget/dist'),('bbf63fef','@craft/commerce/web/assets/purchasablepricefield/dist'),('bd8972ea','@craft/web/assets/fabric/dist'),('cb60d2b8','@craft/web/assets/axios/dist'),('cd5e809','@craft/web/assets/dashboard/dist'),('d0122fb5','@craft/web/assets/conditionbuilder/dist'),('d39547e1','@craft/web/assets/recententries/dist'),('e06c26d6','@craft/web/assets/fieldsettings/dist'),('e0dda4a0','@craft/commerce/web/assets/statwidgets/dist'),('e40051d4','@craft/web/assets/generalsettings/dist'),('e605f3e0','@craft/web/assets/iframeresizer/dist'),('ea8ee567','@craft/commerce/web/assets/chartjs/dist'),('ed2f058f','@craft/web/assets/updateswidget/dist'),('ed64fa57','@craft/web/assets/d3/dist'),('f18e5944','@bower/inputmask/dist'),('f196ea4e','@craft/commerce/web/assets/commerceui/dist'),('f6f919d8','@craft/commerce/web/assets/deepmerge/dist'),('f751dc1e','@craft/web/assets/cp/dist'),('fa2d87c8','@craft/web/assets/installer/dist'),('fb197e56','@craft/web/assets/selectize/dist'),('fc0cc474','@craft/web/assets/tailwindreset/dist'),('fe05cdaa','@craft/commerce/web/assets/commercewidgets/dist'),('fe2aec63','@craft/web/assets/pluginstore/dist');
/*!40000 ALTER TABLE `resourcepaths` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `revisions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int NOT NULL,
  `creatorId` int DEFAULT NULL,
  `num` int NOT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_nkxeprjwlinzbvrlxvqpidtouvdoyphudpta` (`canonicalId`,`num`),
  KEY `fk_gtwvjurclaynavidivoekfzluzmoaiuaxgdn` (`creatorId`),
  CONSTRAINT `fk_gtwvjurclaynavidivoekfzluzmoaiuaxgdn` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_thkcaqleilcszamavrsixntlzjhybfmgtpfr` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindex` (
  `elementId` int NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int NOT NULL,
  `siteId` int NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `idx_bwvjhbpubaigeaciftizqkdvcjwttnjseqau` (`keywords`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
INSERT INTO `searchindex` VALUES (1,'email',0,1,' admin example com '),(1,'firstname',0,1,''),(1,'fullname',0,1,''),(1,'lastname',0,1,''),(1,'slug',0,1,''),(1,'username',0,1,' admin '),(2,'defaultsku',0,1,''),(2,'sku',0,1,''),(2,'slug',0,1,' my test product 1719942569 '),(2,'title',0,1,' my test product 1719942569 '),(3,'defaultsku',0,1,''),(3,'sku',0,1,''),(3,'slug',0,1,' my test product 1719942593 '),(3,'title',0,1,' my test product 1719942593 '),(4,'defaultsku',0,1,''),(4,'sku',0,1,''),(4,'slug',0,1,' my test product 1719942803 '),(4,'title',0,1,' my test product 1719942803 '),(5,'defaultsku',0,1,''),(5,'sku',0,1,''),(5,'slug',0,1,' my test product 1719942899 '),(5,'title',0,1,' my test product 1719942899 '),(6,'defaultsku',0,1,''),(6,'sku',0,1,''),(6,'slug',0,1,' my test product 1719943225 '),(6,'title',0,1,' my test product 1719943225 '),(7,'defaultsku',0,1,''),(7,'sku',0,1,''),(7,'slug',0,1,' my test product 1719943274 '),(7,'title',0,1,' my test product 1719943274 '),(8,'defaultsku',0,1,''),(8,'sku',0,1,''),(8,'slug',0,1,' my test product 1719943366 '),(8,'title',0,1,' my test product 1719943366 '),(9,'defaultsku',0,1,''),(9,'sku',0,1,''),(9,'slug',0,1,' my test product 1719943380 '),(9,'title',0,1,' my test product 1719943380 '),(10,'defaultsku',0,1,''),(10,'sku',0,1,''),(10,'slug',0,1,' my test product 1719943421 '),(10,'title',0,1,' my test product 1719943421 '),(11,'defaultsku',0,1,''),(11,'sku',0,1,''),(11,'slug',0,1,' my test product 1719943435 '),(11,'title',0,1,' my test product 1719943435 '),(12,'defaultsku',0,1,''),(12,'sku',0,1,''),(12,'slug',0,1,' my test product 1719943453 '),(12,'title',0,1,' my test product 1719943453 '),(13,'description',0,1,' my test product 1719943453 my test variant 1719943453 '),(13,'height',0,1,''),(13,'length',0,1,''),(13,'maxqty',0,1,''),(13,'minqty',0,1,''),(13,'price',0,1,' 10 '),(13,'producttitle',0,1,' my test product 1719943453 '),(13,'sku',0,1,' 1719943453 '),(13,'slug',0,1,''),(13,'title',0,1,' my test variant 1719943453 '),(13,'weight',0,1,''),(13,'width',0,1,''),(14,'addressline1',0,1,''),(14,'addressline2',0,1,''),(14,'addressline3',0,1,''),(14,'administrativearea',0,1,''),(14,'countrycode',0,1,' us '),(14,'dependentlocality',0,1,''),(14,'fullname',0,1,''),(14,'locality',0,1,''),(14,'organization',0,1,''),(14,'organizationtaxid',0,1,''),(14,'postalcode',0,1,''),(14,'slug',0,1,''),(14,'sortingcode',0,1,''),(14,'title',0,1,' store '),(16,'defaultsku',0,1,' 123 '),(16,'sku',0,1,''),(16,'slug',0,1,' test '),(16,'title',0,1,' test '),(17,'description',0,1,' test test123 '),(17,'height',0,1,''),(17,'length',0,1,''),(17,'maxqty',0,1,''),(17,'minqty',0,1,''),(17,'price',0,1,' 0 '),(17,'producttitle',0,1,' test '),(17,'sku',0,1,' 123 '),(17,'slug',0,1,' temp nbwkrmwnrbyvbreyfpawtzfuoigkdytiviuq '),(17,'title',0,1,' test123 '),(17,'weight',0,1,''),(17,'width',0,1,''),(18,'slug',0,1,' test '),(18,'title',0,1,' test '),(19,'slug',0,1,' test 2 '),(19,'title',0,1,' test '),(20,'slug',0,1,' test 3 '),(20,'title',0,1,' test '),(21,'slug',0,1,' test 4 '),(21,'title',0,1,' test ');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `maxAuthors` smallint unsigned NOT NULL DEFAULT '1',
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `previewTargets` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_yywpdsslmoyytuwsmuajapkqbelsyfwoyipz` (`handle`),
  KEY `idx_smwofweuwaijtzcssnmfteveigtwqiggketk` (`name`),
  KEY `idx_egdipevzdhwzdersirreomepriimkebwjllw` (`structureId`),
  KEY `idx_moxiccpfquryufskkkwhclwzythhubsaftet` (`dateDeleted`),
  CONSTRAINT `fk_yqtldjmwsndqamxtlayrrxoveqwuntsuggha` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
INSERT INTO `sections` VALUES (1,1,'Product Categories','productCategories','structure',0,1,'all','end',NULL,'2024-07-19 07:59:21','2024-07-19 07:59:21',NULL,'cdec25d5-684f-41ff-8fc7-f0935d020549');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections_entrytypes`
--

DROP TABLE IF EXISTS `sections_entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_entrytypes` (
  `sectionId` int NOT NULL,
  `typeId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`sectionId`,`typeId`),
  KEY `fk_zhzrxmrgrchhqyxsordzsksjhnxsptaxwrli` (`typeId`),
  CONSTRAINT `fk_mukekeashngwjpqrcmjlwmyevfcdqmwgmdyb` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zhzrxmrgrchhqyxsordzsksjhnxsptaxwrli` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections_entrytypes`
--

LOCK TABLES `sections_entrytypes` WRITE;
/*!40000 ALTER TABLE `sections_entrytypes` DISABLE KEYS */;
INSERT INTO `sections_entrytypes` VALUES (1,1,1);
/*!40000 ALTER TABLE `sections_entrytypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_jynmrhcrsqmkbeuutlrbhstrnfhzlroyncks` (`sectionId`,`siteId`),
  KEY `idx_gjgvnoudephncowgmqzidhaawmjvbmueqrri` (`siteId`),
  CONSTRAINT `fk_ocljedgfpazfsllpzdichkfmqyiauvaliphe` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_srelzbdnhehhxkvmralrqdwguwvexivrmnjm` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
INSERT INTO `sections_sites` VALUES (1,1,1,1,'product-categories/{slug}','product-categories/_entry',1,'2024-07-19 07:59:21','2024-07-19 07:59:21','10fb3561-8c29-4b0b-b73f-b5cdff4b07c9');
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_benvhvpvsxplmpurgyrcpurejygbpwupiywk` (`uid`),
  KEY `idx_hpjoitmfglpyfianpnkksdgnxeyvxrgqyyrr` (`token`),
  KEY `idx_ljoeieaefujlehxpawutnwzlaevhupmuzvlo` (`dateUpdated`),
  KEY `idx_ngxwsdhsvxsjthghtwjegxwnfouzyftzobtw` (`userId`),
  CONSTRAINT `fk_jqwqoiiyzbhfolbkozwclpjaxxonunvsqzql` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES (1,1,'RoQwq81vanrRIfd2CPVfwjLEebC9rQCh-NXw26RIse4ghXaxVwz5qMkKFe2R6Om2AIvUJ3c5m2KsUCUA243PtFlp-h9sc-VeUY15','2024-07-02 17:32:38','2024-07-02 18:26:34','058b667d-b030-4f71-8265-6feb8e97c379'),(2,1,'0R6VTHuZ3-qwBt6ATcTcQ5Wh2h2w0rNEJAghABxIMrEqu_t6IXAMq13jK_hu_9SFDenSo9K4x4lYiXvYljaMqMbQH4Zo2IkWzT1D','2024-07-02 18:26:34','2024-07-02 18:39:28','6123c062-b647-4abd-8223-766ada77b318'),(3,1,'hZaGzdWBI_t--jO5oBYl8kTXLlWeDf5r9wg4JkEQTYczIKsFIQ-8gVj_C4Ce6i8f1FjQrEzrqfTbDLSrO9mYaMe70ZdXskhGcCv4','2024-07-19 07:55:41','2024-07-19 08:01:27','fd309871-d332-4402-8eee-61b5b1a0d0ef'),(4,1,'gjcqaRMzZb3kNpv-Rqqv-HqlRjs16SExnv7y5lOnOddWRsflt7pNfBVSmyzw8O7oHFb7JEobXCKS0kqWF_m08_7T2Cp3jeRr-KMS','2024-07-19 08:01:28','2024-07-19 08:11:44','4a4f7dc5-3ffe-4fc1-b825-6f692050c7d2'),(5,1,'ZA2FurzXySuGFLu095M5sOHJmINmoHlLRsJkjA-xKIXBIcQQ06ol-20WMbWWwkIfDKmdz-_mVCwRKC7IthT2vCN87rhFmo7ckJId','2024-07-19 08:11:45','2024-07-19 08:19:08','8494b316-4f8e-48c7-8f17-aad9ac006dad'),(6,1,'9TjLZgdrU7pLHKWyXjAJYZo0KAJtYndKg-eJ908gnkAXlr7oYIYFa8CrIP0SACz5dcq1RDkR3sDvKU_lAoifM9q6thvNwtiAIWow','2024-07-19 09:42:04','2024-07-19 09:42:14','f7c154e4-13ef-40cd-b3a4-19c5f7e5377b');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shunnedmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_bbpzwqekxflcuqihwwabnfkotzzcpqnquhvq` (`userId`,`message`),
  CONSTRAINT `fk_rlmiwiryxsdpvcmoezskpynqecvrsihffaqd` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sitegroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_eetdaojvjbzbnssapunmyxrmqvrazitumelw` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
INSERT INTO `sitegroups` VALUES (1,'Testsite','2024-07-02 17:29:02','2024-07-02 17:29:02',NULL,'48339d33-cdce-440a-95f7-107756106329');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` varchar(255) NOT NULL DEFAULT 'true',
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_atvazczzjpvflwxkxsvzrihkzgajpyzlfdug` (`dateDeleted`),
  KEY `idx_idravqjvpdhdwbxgarokvwsrdxuqquxebocw` (`handle`),
  KEY `idx_bdynsuryjclpvpdwpuclfbofnffodrfclqwa` (`sortOrder`),
  KEY `fk_sgzzsnzgtjnfzrdrfosovyetlqkzjjnflhxq` (`groupId`),
  CONSTRAINT `fk_sgzzsnzgtjnfzrdrfosovyetlqkzjjnflhxq` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
INSERT INTO `sites` VALUES (1,1,1,'true','Testsite','default','en',1,'$DDEV_PRIMARY_URL',1,'2024-07-02 17:29:02','2024-07-02 17:29:02',NULL,'6fc0244d-6ccb-4cb1-b1e5-c10752c00220');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structureelements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `elementId` int DEFAULT NULL,
  `root` int unsigned DEFAULT NULL,
  `lft` int unsigned NOT NULL,
  `rgt` int unsigned NOT NULL,
  `level` smallint unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_meejzuxjamieckjbjyezeuvktyethgsmfxpw` (`structureId`,`elementId`),
  KEY `idx_wabkzdzgjcbjyraksrgtoywtpbejdrlcxyzf` (`root`),
  KEY `idx_zxkdqbpymcsdzfhgajujhdpshzgkmwbgwfsm` (`lft`),
  KEY `idx_vwdpctebvnjntittqvofqznziwxepyzwyurp` (`rgt`),
  KEY `idx_mmwykxcvuigwpemthlwxhaaoykehajczfest` (`level`),
  KEY `idx_vaxhurimgnlbokjizjixtwnejndatevvmrsz` (`elementId`),
  CONSTRAINT `fk_lzvtjalgutucvrcjujhdcjgsdpcmjnhktntt` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
INSERT INTO `structureelements` VALUES (1,1,NULL,1,1,10,0,'2024-07-19 08:14:00','2024-07-19 08:14:03','2b8db114-8d51-4c19-a65c-a211d8dcf269'),(2,1,18,1,2,3,1,'2024-07-19 08:14:00','2024-07-19 08:14:00','60fe17eb-9945-4c92-80e1-e9f4110f4f3f'),(3,1,19,1,4,5,1,'2024-07-19 08:14:03','2024-07-19 08:14:03','0d089143-0d57-44ac-937f-5fcdbb3735d9'),(4,1,20,1,6,7,1,'2024-07-19 08:14:03','2024-07-19 08:14:03','ca333b5a-d459-4909-9654-69664708a642'),(5,1,21,1,8,9,1,'2024-07-19 08:14:03','2024-07-19 08:14:03','cd98f682-c40e-4894-8bbb-3741d4891f55');
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_umjjlibypvjsivpiawvbeehownijxtkylpyu` (`dateDeleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
INSERT INTO `structures` VALUES (1,1,'2024-07-19 07:59:21','2024-07-19 07:59:21',NULL,'e392f163-05ee-442b-a235-cc4cc1554964');
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `systemmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_frxuncnflehahustottrzyyvwspqefzpymqw` (`key`,`language`),
  KEY `idx_gvqxgeuugyzutcpscbzjcvmvecqejnhfxtjh` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `taggroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_oqrwjfjkkdwuqtofccpyqzmypjbrhiayocbn` (`name`),
  KEY `idx_cfbmrblsosjxbcruhibjmwqohzxxmslvwgws` (`handle`),
  KEY `idx_mnrimbqczwqlydbtympqcwlugckestkjqdfx` (`dateDeleted`),
  KEY `fk_epcnmnkqqxtqhvmiyplonoulofqclgomfgia` (`fieldLayoutId`),
  CONSTRAINT `fk_epcnmnkqqxtqhvmiyplonoulofqclgomfgia` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_yhdpsczzesakhfohzzupbzrugquwssntiyqv` (`groupId`),
  CONSTRAINT `fk_aejqhwurqwuvcnkgaevqripfrluoyrjefobt` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cmwvhfwmfswefulcptufmjrcurxkhvyvonre` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text,
  `usageLimit` tinyint unsigned DEFAULT NULL,
  `usageCount` tinyint unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lkwcgvtkaboakqqvyimxuylclexddxzeqjkt` (`token`),
  KEY `idx_gydjrixpznarljseytmpaheutdkhivrtwmbr` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_yhpftpomexdprvegfcwzvxlxyoomrzhjkpyg` (`handle`),
  KEY `idx_nkgamtsmeplmdkrhsijevysskknswbroalqz` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_gizemlzgzizfztykstphpesmubwnspcxtrkp` (`groupId`,`userId`),
  KEY `idx_uqhkpmwwoybikthfdyzfzwparzzyhljixfwq` (`userId`),
  CONSTRAINT `fk_bqctewibuodpalcqblieqfswunxrzugqfkyk` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_iczfbwryjjhywvahweufwtznlmlewnpzzdey` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_pbsnqtqsqacqwvcoeloogdolfjrgbvfoelyt` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `groupId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_bmjswvsdiexehskftoosvftocxifvzgsysjh` (`permissionId`,`groupId`),
  KEY `idx_khwerkjtofzhhgwfoskcaiutknnmepwamoef` (`groupId`),
  CONSTRAINT `fk_bnbwdfvcvniwbimvzfkdrrdtvuvhjijfwbor` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_gxhzcehlsdluqbfwmpcazrzeavexcxdzkrbt` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_wrtznavtmyvacghbijmcuudqtbtsrahfdsgz` (`permissionId`,`userId`),
  KEY `idx_uswavkirracdvqcddtaahdjeiwtsqvcxboja` (`userId`),
  CONSTRAINT `fk_cjnilzfoxkbhearufwrmvhebpqksspbddqdu` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vgqiliyoezkuuglqdlveodyouagdepbqtnvk` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpreferences` (
  `userId` int NOT NULL AUTO_INCREMENT,
  `preferences` json DEFAULT NULL,
  PRIMARY KEY (`userId`),
  CONSTRAINT `fk_ijgasekobumgsrejezksumusrvefhinzqpdv` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
INSERT INTO `userpreferences` VALUES (1,'{\"language\": \"en\"}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL,
  `photoId` int DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `username` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_rhldsfaoqaxchtuyqjkzoppmdgfzztpcajsu` (`active`),
  KEY `idx_dshfeydbodvvcxwetjtxjfjvrjaxdjuzffjm` (`locked`),
  KEY `idx_qvqtwglhznqslyfnhghviefnzlcfoivlkcns` (`pending`),
  KEY `idx_colmopiebnzgghaqvpugjahpeeifmxwkhaaj` (`suspended`),
  KEY `idx_lsrglmcedhvioktfzapbdsgdkjbgafvgzrxv` (`verificationCode`),
  KEY `idx_bovfshaotpfjeodkuwfuncojcsejfauowruy` (`email`),
  KEY `idx_zynywwcyewblmsmxgocgovrbpbauzhrlxzmg` (`username`),
  KEY `fk_oupikutnukeesemtnzkxlbpdjfzkrehhetbo` (`photoId`),
  CONSTRAINT `fk_beclmitpyuzcgcpcdkrfajcdltpcnfsxjyir` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_oupikutnukeesemtnzkxlbpdjfzkrehhetbo` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,NULL,1,0,0,0,1,'admin',NULL,NULL,NULL,'admin@example.com','$2y$13$8pVKnh03vo1VMa8E.V0SzegxqPUkl9oBSYB9RT6N.fCS8hJk78QdO','2024-07-19 09:42:04',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,'2024-07-02 17:29:03','2024-07-02 17:29:03','2024-07-19 09:42:04');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumefolders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `volumeId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_svwdoavznmdraosdwyedfbvqbqtywdenikzo` (`name`,`parentId`,`volumeId`),
  KEY `idx_wgvpeoghrelkvdcudzcppgoqgfeyprbwfxns` (`parentId`),
  KEY `idx_mfnijyjhzinmuwzjdzmndfmuadseukncpibd` (`volumeId`),
  CONSTRAINT `fk_cjyhfafbkbyfltejckuppwygrpeanvgedgbg` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wcxohtfxldlguerfkzpmtvdjcgujapnmwnsc` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fs` varchar(255) NOT NULL,
  `subpath` varchar(255) DEFAULT NULL,
  `transformFs` varchar(255) DEFAULT NULL,
  `transformSubpath` varchar(255) DEFAULT NULL,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `altTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `altTranslationKeyFormat` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_tpdanhrjudvnbedhyophhxwytshtcqkabgho` (`name`),
  KEY `idx_wcfrquaxdzxzsfcqxgnqcaovtnmrwwryrykr` (`handle`),
  KEY `idx_pnmyswznbfghjpcfilbiwrhgmertfuzxfifz` (`fieldLayoutId`),
  KEY `idx_hodtwravsvonuiihhsjqdypkpsyggpyohtof` (`dateDeleted`),
  CONSTRAINT `fk_vpycvftjzxrpjhkkylbqodmjpevkweclaoah` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webauthn`
--

DROP TABLE IF EXISTS `webauthn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webauthn` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `credentialId` varchar(255) DEFAULT NULL,
  `credential` text,
  `credentialName` varchar(255) DEFAULT NULL,
  `dateLastUsed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_kttrtmnwxbxkgvalvntonmvyeltjwhmqysky` (`userId`),
  CONSTRAINT `fk_kttrtmnwxbxkgvalvntonmvyeltjwhmqysky` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webauthn`
--

LOCK TABLES `webauthn` WRITE;
/*!40000 ALTER TABLE `webauthn` DISABLE KEYS */;
/*!40000 ALTER TABLE `webauthn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `widgets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `colspan` tinyint DEFAULT NULL,
  `settings` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_criyasxkhyitkukvkpdjpnkdyvkxeswamrtz` (`userId`),
  CONSTRAINT `fk_dmgbqhbjowsmiamsiujuogvpmfncueavqrlh` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
INSERT INTO `widgets` VALUES (1,1,'craft\\widgets\\RecentEntries',1,NULL,'{\"limit\": 10, \"siteId\": 1, \"section\": \"*\"}',1,'2024-07-02 17:32:39','2024-07-02 17:32:39','c7284c37-d7a4-456b-b6ad-ce67629f5e93'),(2,1,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2024-07-02 17:32:39','2024-07-02 17:32:39','9cfd6b4a-e01b-488f-87e1-ad9bbe1cc365'),(3,1,'craft\\widgets\\Updates',3,NULL,'[]',1,'2024-07-02 17:32:39','2024-07-02 17:32:39','8815cc6f-db89-4e56-bd63-6bd7864de5b0'),(4,1,'craft\\widgets\\Feed',4,NULL,'{\"url\": \"https://craftcms.com/news.rss\", \"limit\": 5, \"title\": \"Craft News\"}',1,'2024-07-02 17:32:39','2024-07-02 17:32:39','e36aa62c-fb38-448b-bf1c-d8342cb6b9d6');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-07-19  9:42:18
